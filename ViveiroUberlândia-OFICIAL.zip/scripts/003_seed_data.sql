-- Categorias iniciais
insert into public.categories (name, slug) values
  ('Plantas Ornamentais', 'plantas-ornamentais'),
  ('Suculentas e Cactos', 'suculentas-e-cactos'),
  ('Frutíferas', 'frutiferas'),
  ('Flores', 'flores')
on conflict (name) do nothing;

-- Configurações iniciais (WhatsApp, Instagram, textos)
insert into public.settings (key, value) values
  ('whatsapp_number', '5534988599082'),
  ('instagram_url', 'https://www.instagram.com/uberlandia.plantas'),
  ('instagram_handle', '@uberlandia.plantas'),
  ('site_address', 'Uberlândia, MG'),
  ('site_maps_query', 'Uberlândia, MG, Brasil'),
  ('hero_title', 'Plantas que transformam seu lar'),
  ('hero_subtitle', 'Viveiro Uberlândia Plantas: ornamentais, suculentas, frutíferas e flores cultivadas com carinho. Receba pelo WhatsApp.'),
  ('about_text', 'O Viveiro Uberlândia Plantas nasceu da paixão por trazer mais verde para o dia a dia das pessoas. Selecionamos cuidadosamente cada muda, oferecemos orientação e entregamos para toda a região.')
on conflict (key) do update set value = excluded.value, updated_at = now();

-- Produtos de exemplo (somente se não houver nenhum)
do $$
declare
  cat_orn uuid;
  cat_suc uuid;
  cat_fru uuid;
  cat_flo uuid;
  product_count int;
begin
  select count(*) into product_count from public.products;
  if product_count = 0 then
    select id into cat_orn from public.categories where slug = 'plantas-ornamentais';
    select id into cat_suc from public.categories where slug = 'suculentas-e-cactos';
    select id into cat_fru from public.categories where slug = 'frutiferas';
    select id into cat_flo from public.categories where slug = 'flores';

    insert into public.products (name, description, price, quantity, image_url, category_id) values
      ('Costela de Adão', 'Monstera deliciosa, folhas grandes e marcantes. Ideal para ambientes internos com boa iluminação indireta.', 89.90, 12, '/images/costela-de-adao.jpg', cat_orn),
      ('Pacová', 'Folhagem tropical exuberante para decorar salas e varandas cobertas.', 65.00, 8, '/images/pacova.jpg', cat_orn),
      ('Echeveria', 'Suculenta em formato de roseta, fácil de cuidar. Perfeita para vasos pequenos.', 18.90, 30, '/images/echeveria.jpg', cat_suc),
      ('Cacto Mandacaru', 'Cacto resistente, tolera muito sol direto. Ótima opção para jardins externos.', 45.00, 10, '/images/cacto-mandacaru.jpg', cat_suc),
      ('Limoeiro Tahiti', 'Muda enxertada de limão Tahiti pronta para frutificar. Rendimento generoso o ano todo.', 79.90, 6, '/images/limoeiro-tahiti.jpg', cat_fru),
      ('Aceroleira', 'Muda de acerola rica em vitamina C. Adapta-se bem ao clima de Uberlândia.', 59.90, 5, '/images/aceroleira.jpg', cat_fru),
      ('Orquídea Phalaenopsis', 'Orquídea borboleta com floração duradoura. Embalagem cuidadosa para presente.', 119.90, 7, '/images/orquidea-phalaenopsis.jpg', cat_flo),
      ('Rosa do Deserto', 'Adenium com floração intensa e tronco escultural. Uma joia para sua coleção.', 149.00, 4, '/images/rosa-do-deserto.jpg', cat_flo);
  end if;
end $$;
