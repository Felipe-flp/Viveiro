-- Cria perfil automaticamente ao criar usuário no auth
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email, role, must_change_password)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1)),
    new.email,
    coalesce(new.raw_user_meta_data ->> 'role', 'user'),
    coalesce((new.raw_user_meta_data ->> 'must_change_password')::boolean, false)
  )
  on conflict (id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();

-- Bloqueia exclusão do super_admin
create or replace function public.prevent_super_admin_delete()
returns trigger
language plpgsql
as $$
begin
  if old.role = 'super_admin' then
    raise exception 'O super administrador não pode ser excluído';
  end if;
  return old;
end;
$$;

drop trigger if exists prevent_super_admin_delete_trg on public.profiles;

create trigger prevent_super_admin_delete_trg
  before delete on public.profiles
  for each row
  execute function public.prevent_super_admin_delete();

-- Impede usuários comuns de mudarem o próprio role
create or replace function public.protect_role_changes()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  caller_role text;
begin
  if old.role is distinct from new.role then
    select role into caller_role from public.profiles where id = auth.uid();
    if caller_role is null or caller_role not in ('admin','super_admin') then
      raise exception 'Apenas administradores podem alterar papéis de usuário';
    end if;
    -- ninguém pode rebaixar o super_admin
    if old.role = 'super_admin' and new.role <> 'super_admin' then
      raise exception 'O super administrador não pode ser rebaixado';
    end if;
  end if;
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists protect_role_changes_trg on public.profiles;

create trigger protect_role_changes_trg
  before update on public.profiles
  for each row
  execute function public.protect_role_changes();
