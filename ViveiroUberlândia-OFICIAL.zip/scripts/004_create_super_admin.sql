-- Cria o super administrador inicial
-- email: felipemarques0710@gmail.com
-- senha padrão: felipeADM123 (deve ser trocada no primeiro login)
do $$
declare
  v_user_id uuid;
  v_email text := 'felipemarques0710@gmail.com';
  v_password text := 'felipeADM123';
begin
  select id into v_user_id from auth.users where email = v_email;

  if v_user_id is null then
    v_user_id := gen_random_uuid();

    insert into auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      email_change,
      email_change_token_new,
      recovery_token
    ) values (
      '00000000-0000-0000-0000-000000000000',
      v_user_id,
      'authenticated',
      'authenticated',
      v_email,
      crypt(v_password, gen_salt('bf')),
      now(),
      '{"provider":"email","providers":["email"]}'::jsonb,
      jsonb_build_object(
        'full_name', 'Felipe Marques',
        'role', 'super_admin',
        'must_change_password', true
      ),
      now(),
      now(),
      '',
      '',
      '',
      ''
    );

    insert into auth.identities (
      id,
      user_id,
      identity_data,
      provider,
      provider_id,
      last_sign_in_at,
      created_at,
      updated_at
    ) values (
      gen_random_uuid(),
      v_user_id,
      jsonb_build_object('sub', v_user_id::text, 'email', v_email),
      'email',
      v_user_id::text,
      now(),
      now(),
      now()
    );
  end if;

  -- Garante que o perfil existe e está marcado como super_admin
  insert into public.profiles (id, full_name, email, role, must_change_password)
  values (v_user_id, 'Felipe Marques', v_email, 'super_admin', true)
  on conflict (id) do update set
    role = 'super_admin',
    full_name = coalesce(excluded.full_name, public.profiles.full_name),
    email = excluded.email;
end $$;
