import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { ProductCard } from "@/components/product-card"
import { WhatsAppFloat } from "@/components/whatsapp-float"
import { createClient } from "@/lib/supabase/server"
import { getSettings } from "@/lib/settings"
import type { Product, Category } from "@/lib/types"
import Link from "next/link"
import { Leaf } from "lucide-react"

type SearchParams = { categoria?: string; q?: string }

export default async function EstoquePage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>
}) {
  const params = await searchParams
  const supabase = await createClient()

  const { data: categories } = await supabase
    .from("categories")
    .select("*")
    .order("name")

  let query = supabase
    .from("products")
    .select("*, categories(*)")
    .eq("active", true)
    .order("created_at", { ascending: false })

  let activeCat: Category | null = null
  if (params.categoria) {
    const cat = (categories ?? []).find((c) => c.slug === params.categoria) ?? null
    if (cat) {
      activeCat = cat as Category
      query = query.eq("category_id", cat.id)
    }
  }

  if (params.q) {
    query = query.ilike("name", `%${params.q}%`)
  }

  const { data: products } = await query
  const items = (products ?? []) as Product[]
  const settings = await getSettings()

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-10 md:px-6 md:py-16">
        <header className="mb-8">
          <p className="mb-2 text-sm font-medium uppercase tracking-wider text-primary">
            Catálogo
          </p>
          <h1 className="font-serif text-3xl font-semibold md:text-4xl">
            {activeCat ? activeCat.name : "Nosso estoque"}
          </h1>
          <p className="mt-2 max-w-2xl text-muted-foreground">
            Mudas e plantas atualizadas em tempo real. Os preços e quantidades
            disponíveis você vê aqui.
          </p>
        </header>

        <div className="mb-8 flex flex-wrap gap-2">
          <Link
            href="/estoque"
            className={`rounded-full border px-4 py-1.5 text-sm transition ${
              !activeCat
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-foreground hover:border-primary/50"
            }`}
          >
            Todas
          </Link>
          {(categories ?? []).map((c) => (
            <Link
              key={c.id}
              href={`/estoque?categoria=${c.slug}`}
              className={`rounded-full border px-4 py-1.5 text-sm transition ${
                activeCat?.id === c.id
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card text-foreground hover:border-primary/50"
              }`}
            >
              {c.name}
            </Link>
          ))}
        </div>

        {items.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border bg-card p-12 text-center">
            <Leaf className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
            <p className="font-serif text-lg">Nenhum produto disponível</p>
            <p className="mt-1 text-sm text-muted-foreground">
              {activeCat
                ? "Esta categoria ainda não possui produtos."
                : "Em breve novos produtos por aqui."}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {items.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </main>

      <SiteFooter />
      <WhatsAppFloat phone={settings.whatsapp || "5534988599082"} />
    </div>
  )
}
