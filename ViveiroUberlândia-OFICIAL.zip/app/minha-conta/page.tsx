import Link from "next/link"
import { redirect } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { createClient } from "@/lib/supabase/server"
import { formatBRL, formatDate } from "@/lib/format"
import { Badge } from "@/components/ui/badge"
import type { Order } from "@/lib/types"
import { ShoppingBag, ChevronRight } from "lucide-react"

const STATUS_LABELS: Record<string, { label: string; className: string }> = {
  pending: { label: "Aguardando", className: "bg-accent/20 text-accent-foreground" },
  confirmed: { label: "Confirmado", className: "bg-primary/15 text-primary" },
  delivered: { label: "Entregue", className: "bg-primary/15 text-primary" },
  cancelled: { label: "Cancelado", className: "bg-destructive/15 text-destructive" },
}

export default async function MinhaContaPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) redirect("/login?redirect=/minha-conta")

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single()

  const { data: orders } = await supabase
    .from("orders")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  const list = (orders ?? []) as Order[]

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-10 md:px-6 md:py-16">
        <header className="mb-10">
          <p className="mb-2 text-sm font-medium uppercase tracking-wider text-primary">
            Minha conta
          </p>
          <h1 className="font-serif text-3xl font-semibold md:text-4xl">
            Olá, {profile?.full_name || "cliente"}!
          </h1>
          <p className="mt-2 text-muted-foreground">{profile?.email}</p>
        </header>

        <section>
          <h2 className="mb-4 font-serif text-2xl font-semibold">Meus pedidos</h2>

          {list.length === 0 ? (
            <div className="rounded-xl border border-dashed border-border bg-card p-10 text-center">
              <ShoppingBag className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
              <p className="font-serif text-lg">Você ainda não fez pedidos</p>
              <Link
                href="/estoque"
                className="mt-3 inline-block text-sm font-medium text-primary hover:underline"
              >
                Conheça nosso estoque →
              </Link>
            </div>
          ) : (
            <ul className="divide-y divide-border overflow-hidden rounded-xl border border-border bg-card">
              {list.map((order) => {
                const status = STATUS_LABELS[order.status] ?? STATUS_LABELS.pending
                return (
                  <li key={order.id}>
                    <Link
                      href={`/minha-conta/pedidos/${order.id}`}
                      className="flex items-center justify-between gap-4 p-5 transition hover:bg-secondary/50"
                    >
                      <div>
                        <p className="font-serif text-lg font-semibold">
                          Pedido #{order.id.slice(0, 8)}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {formatDate(order.created_at)}
                        </p>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge className={status.className}>{status.label}</Badge>
                        <span className="font-serif text-lg font-semibold">
                          {formatBRL(order.total)}
                        </span>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </div>
                    </Link>
                  </li>
                )
              })}
            </ul>
          )}
        </section>
      </main>

      <SiteFooter />
    </div>
  )
}
