import { notFound, redirect } from "next/navigation"
import Link from "next/link"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { createClient } from "@/lib/supabase/server"
import { formatBRL, formatDate } from "@/lib/format"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronLeft, MessageCircle } from "lucide-react"
import { getSettings } from "@/lib/settings"

const STATUS_LABELS: Record<string, { label: string; className: string }> = {
  pending: { label: "Aguardando confirmação", className: "bg-accent/20 text-accent-foreground" },
  confirmed: { label: "Confirmado", className: "bg-primary/15 text-primary" },
  delivered: { label: "Entregue", className: "bg-primary/15 text-primary" },
  cancelled: { label: "Cancelado", className: "bg-destructive/15 text-destructive" },
}

export default async function OrderDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) redirect("/login")

  const { data: order } = await supabase.from("orders").select("*").eq("id", id).single()
  if (!order) notFound()

  const { data: items } = await supabase
    .from("order_items")
    .select("*")
    .eq("order_id", id)

  const settings = await getSettings()
  const status = STATUS_LABELS[order.status] ?? STATUS_LABELS.pending
  const whatsapp = settings.whatsapp || "5534988599082"
  const message = encodeURIComponent(
    `Olá! Gostaria de saber sobre o pedido #${order.id.slice(0, 8)}.`,
  )

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-10 md:px-6 md:py-16">
        <Link
          href="/minha-conta"
          className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ChevronLeft className="h-4 w-4" /> Voltar
        </Link>

        <div className="mb-8 flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="font-serif text-3xl font-semibold">
              Pedido #{order.id.slice(0, 8)}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {formatDate(order.created_at)}
            </p>
          </div>
          <Badge className={status.className}>{status.label}</Badge>
        </div>

        <div className="overflow-hidden rounded-xl border border-border bg-card">
          <ul className="divide-y divide-border">
            {(items ?? []).map((item) => (
              <li key={item.id} className="flex items-start justify-between gap-4 p-4">
                <div>
                  <p className="font-medium">{item.product_name}</p>
                  <p className="text-sm text-muted-foreground">
                    {item.quantity} × {formatBRL(item.unit_price)}
                  </p>
                </div>
                <p className="font-serif font-semibold">{formatBRL(item.subtotal)}</p>
              </li>
            ))}
          </ul>
          <div className="flex items-center justify-between border-t border-border bg-secondary/30 p-4">
            <span className="font-medium">Total</span>
            <span className="font-serif text-2xl font-semibold text-primary">
              {formatBRL(order.total)}
            </span>
          </div>
        </div>

        <div className="mt-8 rounded-xl border border-border bg-card p-6">
          <h2 className="font-serif text-lg font-semibold">Próximos passos</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Combine a entrega e o pagamento direto no WhatsApp. Estamos prontos para
            te atender.
          </p>
          <Button asChild className="mt-4">
            <a
              href={`https://wa.me/${whatsapp}?text=${message}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <MessageCircle className="mr-2 h-4 w-4" />
              Falar no WhatsApp
            </a>
          </Button>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
