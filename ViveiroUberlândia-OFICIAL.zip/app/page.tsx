import Image from "next/image"
import Link from "next/link"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Button } from "@/components/ui/button"
import { ProductCard } from "@/components/product-card"
import { WhatsAppFloat } from "@/components/whatsapp-float"
import { createClient } from "@/lib/supabase/server"
import { getSettings } from "@/lib/settings"
import { ArrowRight, Leaf, Truck, ShieldCheck, HeartHandshake } from "lucide-react"
import type { Product, Category } from "@/lib/types"

const categoryImages: Record<string, string> = {
  "plantas-ornamentais": "/images/cat-ornamentais.jpg",
  "suculentas-e-cactos": "/images/cat-suculentas.jpg",
  frutiferas: "/images/cat-frutiferas.jpg",
  flores: "/images/cat-flores.jpg",
}

export default async function HomePage() {
  const supabase = await createClient()
  const [{ data: products }, { data: categories }, settings] = await Promise.all([
    supabase
      .from("products")
      .select("*, categories(*)")
      .eq("active", true)
      .order("created_at", { ascending: false })
      .limit(8),
    supabase.from("categories").select("*").order("name"),
    getSettings(),
  ])

  const featured = (products ?? []) as Product[]
  const cats = (categories ?? []) as Category[]
  const whatsapp = settings.whatsapp || "5534988599082"
  const heroText =
    settings.hero_text ||
    "Plantas selecionadas com carinho para transformar seu lar em um refúgio verde."

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="flex-1">
        {/* HERO */}
        <section className="relative overflow-hidden bg-secondary/40">
          <div className="mx-auto grid max-w-7xl items-center gap-8 px-4 py-12 md:grid-cols-2 md:gap-12 md:px-6 md:py-20 lg:py-28">
            <div className="flex flex-col gap-6">
              <span className="inline-flex w-fit items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium uppercase tracking-wider text-primary">
                <Leaf className="h-3.5 w-3.5" />
                Viveiro local em Uberlândia
              </span>
              <h1 className="text-balance font-serif text-4xl font-semibold leading-[1.05] tracking-tight md:text-5xl lg:text-6xl">
                {settings.site_subtitle || "Sua loja de plantas em Uberlândia"}
              </h1>
              <p className="max-w-lg text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
                {heroText}
              </p>
              <div className="flex flex-wrap gap-3">
                <Button asChild size="lg">
                  <Link href="/estoque">
                    Ver estoque
                    <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline">
                  <a
                    href={`https://wa.me/${whatsapp}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Falar no WhatsApp
                  </a>
                </Button>
              </div>
              <div className="flex flex-wrap gap-6 pt-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Truck className="h-4 w-4 text-primary" />
                  Entrega em Uberlândia
                </div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-primary" />
                  Plantas saudáveis
                </div>
                <div className="flex items-center gap-2">
                  <HeartHandshake className="h-4 w-4 text-primary" />
                  Atendimento humano
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="relative aspect-[4/5] overflow-hidden rounded-2xl bg-muted shadow-xl md:aspect-[3/4]">
                <Image
                  src="/images/hero-plants.jpg"
                  alt="Plantas variadas em vasos de barro"
                  fill
                  priority
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 50vw"
                />
              </div>
              <div className="absolute -bottom-4 -left-4 hidden rounded-xl bg-card p-4 shadow-lg md:block">
                <p className="font-serif text-2xl font-semibold text-primary">+200</p>
                <p className="text-xs text-muted-foreground">
                  espécies disponíveis
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CATEGORIAS */}
        <section className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24">
          <div className="mb-10 flex items-end justify-between gap-4">
            <div>
              <p className="mb-2 text-sm font-medium uppercase tracking-wider text-primary">
                Categorias
              </p>
              <h2 className="font-serif text-3xl font-semibold md:text-4xl">
                Explore por tipo de planta
              </h2>
            </div>
            <Button asChild variant="ghost" className="hidden md:inline-flex">
              <Link href="/estoque">
                Ver todas
                <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
            {cats.map((cat) => (
              <Link
                key={cat.id}
                href={`/estoque?categoria=${cat.slug}`}
                className="group relative aspect-[4/5] overflow-hidden rounded-xl bg-muted"
              >
                <Image
                  src={categoryImages[cat.slug] || "/placeholder.svg"}
                  alt={cat.name}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                  sizes="(max-width: 768px) 50vw, 25vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-4">
                  <h3 className="font-serif text-lg font-medium text-white md:text-xl">
                    {cat.name}
                  </h3>
                  <p className="mt-1 flex items-center gap-1 text-sm text-white/80">
                    Ver produtos
                    <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* DESTAQUES */}
        <section className="bg-secondary/40 py-16 md:py-24">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="mb-10 flex items-end justify-between gap-4">
              <div>
                <p className="mb-2 text-sm font-medium uppercase tracking-wider text-primary">
                  Em destaque
                </p>
                <h2 className="font-serif text-3xl font-semibold md:text-4xl">
                  Plantas para você
                </h2>
              </div>
              <Button asChild variant="outline">
                <Link href="/estoque">
                  Ver tudo
                  <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
            {featured.length === 0 ? (
              <div className="rounded-xl border border-dashed border-border bg-card p-12 text-center">
                <Leaf className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
                <p className="font-serif text-lg">
                  Em breve novos produtos por aqui
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Cadastre produtos no painel admin para vê-los listados.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
                {featured.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>
        </section>

        {/* SOBRE */}
        <section className="mx-auto grid max-w-7xl gap-10 px-4 py-16 md:grid-cols-2 md:gap-16 md:px-6 md:py-24">
          <div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-muted md:aspect-[5/4]">
            <Image
              src="/images/sobre-viveiro.jpg"
              alt="Interior do viveiro"
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 50vw"
            />
          </div>
          <div className="flex flex-col justify-center gap-6">
            <p className="text-sm font-medium uppercase tracking-wider text-primary">
              Sobre nós
            </p>
            <h2 className="font-serif text-3xl font-semibold md:text-4xl">
              Plantas saudáveis, atendimento próximo
            </h2>
            <p className="text-pretty leading-relaxed text-muted-foreground">
              {settings.about_text ||
                "O Viveiro Uberlândia Plantas é especializado em mudas, ornamentais, suculentas, cactos, flores e frutíferas. Atendemos com cuidado, oferecendo plantas saudáveis e dicas de cultivo para você ter sempre o melhor da natureza em casa."}
            </p>
            <div className="flex flex-wrap gap-3">
              <Button asChild>
                <Link href="/sobre">Conheça nossa história</Link>
              </Button>
              <Button asChild variant="outline">
                <Link href="/contato">Onde estamos</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
      <WhatsAppFloat phone={whatsapp} />
    </div>
  )
}
