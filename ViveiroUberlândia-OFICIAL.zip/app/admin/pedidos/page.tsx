import Link from "next/link"
import { createClient } from "@/lib/supabase/server"
import { formatBRL, formatDate } from "@/lib/format"
import { Badge } from "@/components/ui/badge"
import { ChevronRight, ClipboardList } from "lucide-react"
import type { Order } from "@/lib/types"

const STATUS_LABELS: Record<string, { label: string; className: string }> = {
  pending: { label: "Aguardando", className: "bg-accent/20 text-accent-foreground" },
  confirmed: { label: "Confirmado", className: "bg-primary/15 text-primary" },
  delivered: { label: "Entregue", className: "bg-primary/15 text-primary" },
  cancelled: { label: "Cancelado", className: "bg-destructive/15 text-destructive" },
}

const FILTERS = [
  { value: "", label: "Todos" },
  { value: "pending", label: "Aguardando" },
  { value: "confirmed", label: "Confirmados" },
  { value: "delivered", label: "Entregues" },
  { value: "cancelled", label: "Cancelados" },
]

export default async function AdminPedidosPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>
}) {
  const params = await searchParams
  const supabase = await createClient()

  let query = supabase.from("orders").select("*").order("created_at", { ascending: false })
  if (params.status) {
    query = query.eq("status", params.status)
  }
  const { data } = await query
  const orders = (data ?? []) as Order[]

  return (
    <div className="space-y-6">
      <header>
        <p className="text-sm font-medium uppercase tracking-wider text-primary">
          Vendas
        </p>
        <h1 className="font-serif text-3xl font-semibold">Pedidos</h1>
      </header>

      <div className="flex flex-wrap gap-2">
        {FILTERS.map((f) => {
          const active = (params.status ?? "") === f.value
          return (
            <Link
              key={f.value}
              href={f.value ? `/admin/pedidos?status=${f.value}` : "/admin/pedidos"}
              className={`rounded-full border px-4 py-1.5 text-sm transition ${
                active
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card hover:border-primary/50"
              }`}
            >
              {f.label}
            </Link>
          )
        })}
      </div>

      {orders.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border bg-card p-12 text-center">
          <ClipboardList className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
          <p className="font-serif text-lg">Nenhum pedido encontrado</p>
        </div>
      ) : (
        <ul className="divide-y divide-border overflow-hidden rounded-xl border border-border bg-card">
          {orders.map((o) => {
            const status = STATUS_LABELS[o.status] ?? STATUS_LABELS.pending
            return (
              <li key={o.id}>
                <Link
                  href={`/admin/pedidos/${o.id}`}
                  className="flex items-center justify-between gap-4 p-5 transition hover:bg-secondary/50"
                >
                  <div className="min-w-0">
                    <p className="font-serif text-lg font-semibold">
                      #{o.id.slice(0, 8)}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {o.customer_name || "Cliente"} • {formatDate(o.created_at)}
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <Badge className={status.className}>{status.label}</Badge>
                    <span className="font-serif text-lg font-semibold">
                      {formatBRL(o.total)}
                    </span>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </Link>
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}
