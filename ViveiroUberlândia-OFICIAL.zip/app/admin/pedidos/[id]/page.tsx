import Link from "next/link"
import { notFound } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { formatBRL, formatDate } from "@/lib/format"
import { ChevronLeft, MessageCircle, User, Phone, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { OrderStatusForm } from "@/components/admin/order-status-form"
import type { OrderItem, Order } from "@/lib/types"
import { getSettings } from "@/lib/settings"

export default async function AdminOrderPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()
  const { data: order } = await supabase.from("orders").select("*").eq("id", id).single()
  if (!order) notFound()

  const { data: items } = await supabase
    .from("order_items")
    .select("*")
    .eq("order_id", id)

  let userEmail: string | null = null
  if (order.user_id) {
    const { data: profile } = await supabase
      .from("profiles")
      .select("email")
      .eq("id", order.user_id)
      .single()
    userEmail = profile?.email ?? null
  }

  const settings = await getSettings()
  const whatsapp = order.customer_phone?.replace(/\D/g, "") || ""

  return (
    <div className="space-y-6">
      <Link
        href="/admin/pedidos"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ChevronLeft className="h-4 w-4" /> Pedidos
      </Link>

      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium uppercase tracking-wider text-primary">
            Pedido
          </p>
          <h1 className="font-serif text-3xl font-semibold">
            #{(order as Order).id.slice(0, 8)}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {formatDate(order.created_at)}
          </p>
        </div>
        <OrderStatusForm orderId={order.id} initialStatus={order.status} />
      </header>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <section className="overflow-hidden rounded-xl border border-border bg-card">
            <header className="border-b border-border p-5">
              <h2 className="font-serif text-lg font-semibold">Itens do pedido</h2>
            </header>
            <ul className="divide-y divide-border">
              {((items ?? []) as OrderItem[]).map((it) => (
                <li
                  key={it.id}
                  className="flex items-start justify-between gap-3 p-4"
                >
                  <div>
                    <p className="font-medium">{it.product_name}</p>
                    <p className="text-sm text-muted-foreground">
                      {it.quantity} × {formatBRL(it.unit_price)}
                    </p>
                  </div>
                  <p className="font-serif font-semibold">{formatBRL(it.subtotal)}</p>
                </li>
              ))}
            </ul>
            <div className="flex items-center justify-between border-t border-border bg-secondary/30 p-4">
              <span className="font-medium">Total</span>
              <span className="font-serif text-2xl font-semibold text-primary">
                {formatBRL(order.total)}
              </span>
            </div>
          </section>
        </div>

        <aside className="space-y-4">
          <section className="rounded-xl border border-border bg-card p-5">
            <h3 className="font-serif text-base font-semibold">Cliente</h3>
            <ul className="mt-3 space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                {order.customer_name || "—"}
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-muted-foreground" />
                {order.customer_phone || "—"}
              </li>
              {userEmail && (
                <li className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  {userEmail}
                </li>
              )}
            </ul>
            {whatsapp && (
              <Button asChild className="mt-4 w-full">
                <a
                  href={`https://wa.me/55${whatsapp.replace(/^55/, "")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <MessageCircle className="mr-1 h-4 w-4" />
                  Falar com cliente
                </a>
              </Button>
            )}
          </section>

          {order.whatsapp_message && (
            <section className="rounded-xl border border-border bg-card p-5">
              <h3 className="font-serif text-base font-semibold">
                Mensagem enviada
              </h3>
              <pre className="mt-3 max-h-64 overflow-auto whitespace-pre-wrap rounded-md bg-secondary/50 p-3 font-sans text-xs text-muted-foreground">
                {order.whatsapp_message}
              </pre>
            </section>
          )}
        </aside>
      </div>
    </div>
  )
}
