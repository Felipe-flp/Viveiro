import Link from "next/link"
import { createClient } from "@/lib/supabase/server"
import { Package, ClipboardList, AlertTriangle, TrendingUp } from "lucide-react"
import { formatBRL, formatDate } from "@/lib/format"
import { Badge } from "@/components/ui/badge"
import type { Order } from "@/lib/types"

const STATUS_LABELS: Record<string, { label: string; className: string }> = {
  pending: { label: "Aguardando", className: "bg-accent/20 text-accent-foreground" },
  confirmed: { label: "Confirmado", className: "bg-primary/15 text-primary" },
  delivered: { label: "Entregue", className: "bg-primary/15 text-primary" },
  cancelled: { label: "Cancelado", className: "bg-destructive/15 text-destructive" },
}

export default async function AdminDashboardPage() {
  const supabase = await createClient()

  const [{ count: productCount }, { count: pendingCount }, { data: lowStock }, { data: recentOrders }, { data: pendingTotal }] =
    await Promise.all([
      supabase.from("products").select("*", { count: "exact", head: true }).eq("active", true),
      supabase.from("orders").select("*", { count: "exact", head: true }).eq("status", "pending"),
      supabase.from("products").select("id, name, quantity").eq("active", true).lte("quantity", 3).order("quantity").limit(5),
      supabase.from("orders").select("*").order("created_at", { ascending: false }).limit(5),
      supabase.from("orders").select("total").in("status", ["pending", "confirmed"]),
    ])

  const totalRevenue =
    (pendingTotal ?? []).reduce((acc, o) => acc + Number(o.total ?? 0), 0)

  const orders = (recentOrders ?? []) as Order[]

  return (
    <div className="space-y-8">
      <header>
        <p className="text-sm font-medium uppercase tracking-wider text-primary">
          Painel administrativo
        </p>
        <h1 className="font-serif text-3xl font-semibold">Visão geral</h1>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Produtos ativos"
          value={String(productCount ?? 0)}
          icon={Package}
          href="/admin/produtos"
        />
        <StatCard
          title="Pedidos pendentes"
          value={String(pendingCount ?? 0)}
          icon={ClipboardList}
          href="/admin/pedidos?status=pending"
          accent
        />
        <StatCard
          title="Estoque baixo"
          value={String((lowStock ?? []).length)}
          icon={AlertTriangle}
          href="/admin/produtos"
        />
        <StatCard
          title="Em andamento"
          value={formatBRL(totalRevenue)}
          icon={TrendingUp}
          href="/admin/pedidos"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-xl border border-border bg-card">
          <header className="flex items-center justify-between border-b border-border p-5">
            <h2 className="font-serif text-lg font-semibold">Pedidos recentes</h2>
            <Link
              href="/admin/pedidos"
              className="text-sm font-medium text-primary hover:underline"
            >
              Ver todos
            </Link>
          </header>
          {orders.length === 0 ? (
            <p className="p-6 text-sm text-muted-foreground">
              Ainda não há pedidos.
            </p>
          ) : (
            <ul className="divide-y divide-border">
              {orders.map((order) => {
                const status =
                  STATUS_LABELS[order.status] ?? STATUS_LABELS.pending
                return (
                  <li key={order.id}>
                    <Link
                      href={`/admin/pedidos/${order.id}`}
                      className="flex items-center justify-between gap-3 p-4 hover:bg-secondary/50"
                    >
                      <div className="min-w-0">
                        <p className="font-medium">
                          #{order.id.slice(0, 8)} — {order.customer_name || "Cliente"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {formatDate(order.created_at)}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge className={status.className}>{status.label}</Badge>
                        <span className="font-serif font-semibold">
                          {formatBRL(order.total)}
                        </span>
                      </div>
                    </Link>
                  </li>
                )
              })}
            </ul>
          )}
        </section>

        <section className="rounded-xl border border-border bg-card">
          <header className="flex items-center justify-between border-b border-border p-5">
            <h2 className="font-serif text-lg font-semibold">Estoque baixo</h2>
            <Link
              href="/admin/produtos"
              className="text-sm font-medium text-primary hover:underline"
            >
              Gerenciar
            </Link>
          </header>
          {(lowStock ?? []).length === 0 ? (
            <p className="p-6 text-sm text-muted-foreground">
              Tudo certo! Sem produtos com estoque baixo.
            </p>
          ) : (
            <ul className="divide-y divide-border">
              {(lowStock ?? []).map((p) => (
                <li
                  key={p.id}
                  className="flex items-center justify-between gap-3 p-4"
                >
                  <span className="font-medium">{p.name}</span>
                  <span
                    className={`rounded-full px-3 py-0.5 text-xs font-semibold ${
                      p.quantity === 0
                        ? "bg-destructive/15 text-destructive"
                        : "bg-accent/20 text-accent-foreground"
                    }`}
                  >
                    {p.quantity === 0 ? "Esgotado" : `${p.quantity} em estoque`}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  )
}

function StatCard({
  title,
  value,
  icon: Icon,
  href,
  accent,
}: {
  title: string
  value: string
  icon: any
  href: string
  accent?: boolean
}) {
  return (
    <Link
      href={href}
      className={`group flex items-start justify-between rounded-xl border p-5 transition hover:shadow-md ${
        accent
          ? "border-accent/40 bg-accent/10"
          : "border-border bg-card"
      }`}
    >
      <div>
        <p className="text-sm text-muted-foreground">{title}</p>
        <p className="mt-2 font-serif text-2xl font-semibold">{value}</p>
      </div>
      <span
        className={`flex h-10 w-10 items-center justify-center rounded-lg ${
          accent ? "bg-accent/20 text-accent-foreground" : "bg-primary/10 text-primary"
        }`}
      >
        <Icon className="h-5 w-5" />
      </span>
    </Link>
  )
}
