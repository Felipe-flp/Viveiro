import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { ChangePasswordForm } from "@/components/admin/change-password-form"
import { Logo } from "@/components/logo"
import { ShieldAlert } from "lucide-react"

export default async function TrocarSenhaPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) redirect("/login")

  const { data: profile } = await supabase
    .from("profiles")
    .select("role, must_change_password, full_name")
    .eq("id", user.id)
    .single()

  if (!profile || (profile.role !== "admin" && profile.role !== "super_admin")) {
    redirect("/")
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-secondary/40 p-4">
      <div className="w-full max-w-md rounded-2xl border border-border bg-card p-8 shadow-lg">
        <div className="mb-6 flex flex-col items-center gap-3 text-center">
          <Logo />
          <span className="mt-2 flex h-12 w-12 items-center justify-center rounded-full bg-accent/15 text-accent">
            <ShieldAlert className="h-6 w-6" />
          </span>
          <h1 className="font-serif text-2xl font-semibold">
            {profile.must_change_password
              ? "Defina uma nova senha"
              : "Alterar senha"}
          </h1>
          <p className="text-sm text-muted-foreground">
            {profile.must_change_password
              ? "Por segurança, é necessário trocar a senha temporária antes de continuar."
              : "Crie uma nova senha para sua conta."}
          </p>
        </div>
        <ChangePasswordForm forced={profile.must_change_password} />
      </div>
    </div>
  )
}
