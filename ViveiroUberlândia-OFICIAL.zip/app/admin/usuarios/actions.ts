"use server"

import { createClient as createServerClient } from "@/lib/supabase/server"
import { createAdminClient } from "@/lib/supabase/admin"
import { revalidatePath } from "next/cache"

async function requireSuperAdmin() {
  const supabase = await createServerClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return { ok: false, error: "Não autenticado." }
  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single()
  if (profile?.role !== "super_admin") {
    return { ok: false, error: "Acesso negado." }
  }
  return { ok: true, userId: user.id }
}

export async function createAdminAction(formData: FormData) {
  const auth = await requireSuperAdmin()
  if (!auth.ok) return { ok: false, error: auth.error }

  const email = String(formData.get("email") ?? "").trim().toLowerCase()
  const fullName = String(formData.get("full_name") ?? "").trim()
  const password = String(formData.get("password") ?? "")

  if (!email || !password || password.length < 8) {
    return { ok: false, error: "E-mail e senha (mín. 8) são obrigatórios." }
  }

  const admin = createAdminClient()
  const { data, error } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: {
      full_name: fullName,
      role: "admin",
      must_change_password: true,
    },
  })

  if (error) return { ok: false, error: error.message }

  // ensure profile is correctly set
  if (data.user) {
    await admin.from("profiles").upsert({
      id: data.user.id,
      email,
      full_name: fullName || null,
      role: "admin",
      must_change_password: true,
    })
  }

  revalidatePath("/admin/usuarios")
  return { ok: true }
}

export async function removeAdminAction(formData: FormData) {
  const auth = await requireSuperAdmin()
  if (!auth.ok) return { ok: false, error: auth.error }

  const userId = String(formData.get("user_id") ?? "")
  if (!userId) return { ok: false, error: "ID inválido." }
  if (userId === auth.userId) {
    return { ok: false, error: "Você não pode remover sua própria conta." }
  }

  const admin = createAdminClient()
  // verify it's an admin (not super_admin)
  const { data: target } = await admin
    .from("profiles")
    .select("role")
    .eq("id", userId)
    .single()
  if (!target) return { ok: false, error: "Usuário não encontrado." }
  if (target.role === "super_admin") {
    return { ok: false, error: "Não é possível remover um Super Admin." }
  }

  const { error } = await admin.auth.admin.deleteUser(userId)
  if (error) return { ok: false, error: error.message }

  revalidatePath("/admin/usuarios")
  return { ok: true }
}

export async function resetAdminPasswordAction(formData: FormData) {
  const auth = await requireSuperAdmin()
  if (!auth.ok) return { ok: false, error: auth.error }

  const userId = String(formData.get("user_id") ?? "")
  const newPassword = String(formData.get("password") ?? "")
  if (!userId || newPassword.length < 8) {
    return { ok: false, error: "Senha mínima de 8 caracteres." }
  }

  const admin = createAdminClient()
  const { error } = await admin.auth.admin.updateUserById(userId, {
    password: newPassword,
  })
  if (error) return { ok: false, error: error.message }

  await admin
    .from("profiles")
    .update({ must_change_password: true })
    .eq("id", userId)

  revalidatePath("/admin/usuarios")
  return { ok: true }
}
