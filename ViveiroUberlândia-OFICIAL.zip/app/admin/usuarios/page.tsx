import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Badge } from "@/components/ui/badge"
import { ShieldCheck, User, Crown } from "lucide-react"
import { CreateAdminDialog } from "@/components/admin/create-admin-dialog"
import { UserActions } from "@/components/admin/user-actions"
import type { Profile } from "@/lib/types"

export default async function AdminUsuariosPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) redirect("/login")

  const { data: me } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single()

  if (me?.role !== "super_admin") redirect("/admin")

  const { data: profiles } = await supabase
    .from("profiles")
    .select("*")
    .order("created_at", { ascending: false })

  const list = (profiles ?? []) as Profile[]
  const admins = list.filter((p) => p.role === "admin" || p.role === "super_admin")
  const customers = list.filter((p) => p.role === "user")

  return (
    <div className="space-y-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-medium uppercase tracking-wider text-primary">
            Equipe
          </p>
          <h1 className="font-serif text-3xl font-semibold">Usuários</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Gerencie administradores e veja seus clientes.
          </p>
        </div>
        <CreateAdminDialog />
      </header>

      <section>
        <h2 className="mb-3 font-serif text-xl font-semibold">Administradores</h2>
        <ul className="divide-y divide-border overflow-hidden rounded-xl border border-border bg-card">
          {admins.map((p) => (
            <li
              key={p.id}
              className="flex flex-wrap items-center gap-3 p-4 sm:flex-nowrap"
            >
              <span
                className={`flex h-10 w-10 items-center justify-center rounded-full ${
                  p.role === "super_admin"
                    ? "bg-accent/15 text-accent"
                    : "bg-primary/15 text-primary"
                }`}
              >
                {p.role === "super_admin" ? (
                  <Crown className="h-5 w-5" />
                ) : (
                  <ShieldCheck className="h-5 w-5" />
                )}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{p.full_name || "Sem nome"}</p>
                <p className="truncate text-xs text-muted-foreground">{p.email}</p>
              </div>
              <Badge
                className={
                  p.role === "super_admin"
                    ? "bg-accent/15 text-accent-foreground"
                    : "bg-primary/15 text-primary"
                }
              >
                {p.role === "super_admin" ? "Super Admin" : "Admin"}
              </Badge>
              {p.must_change_password && (
                <Badge variant="secondary">Senha temporária</Badge>
              )}
              {p.id !== user.id && p.role !== "super_admin" && (
                <UserActions userId={p.id} email={p.email ?? ""} />
              )}
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2 className="mb-3 font-serif text-xl font-semibold">
          Clientes ({customers.length})
        </h2>
        {customers.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border bg-card p-8 text-center text-sm text-muted-foreground">
            Ainda não há clientes cadastrados.
          </div>
        ) : (
          <ul className="divide-y divide-border overflow-hidden rounded-xl border border-border bg-card">
            {customers.map((p) => (
              <li
                key={p.id}
                className="flex flex-wrap items-center gap-3 p-4 sm:flex-nowrap"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
                  <User className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">
                    {p.full_name || "Sem nome"}
                  </p>
                  <p className="truncate text-xs text-muted-foreground">
                    {p.email}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  )
}
