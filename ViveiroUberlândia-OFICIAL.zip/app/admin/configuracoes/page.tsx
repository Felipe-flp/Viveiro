import { getSettings } from "@/lib/settings"
import { SettingsForm } from "@/components/admin/settings-form"

export default async function ConfiguracoesPage() {
  const settings = await getSettings()
  return (
    <div className="space-y-6">
      <header>
        <p className="text-sm font-medium uppercase tracking-wider text-primary">
          Configurações
        </p>
        <h1 className="font-serif text-3xl font-semibold">
          Informações do site
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Atualize WhatsApp, Instagram, endereço e textos exibidos no site.
        </p>
      </header>
      <SettingsForm initial={settings} />
    </div>
  )
}
