"use server"

import { createClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function saveSettingsAction(formData: FormData) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return { ok: false, error: "Não autenticado." }

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single()
  if (profile?.role !== "admin" && profile?.role !== "super_admin") {
    return { ok: false, error: "Acesso negado." }
  }

  const entries = Array.from(formData.entries()).map(([key, value]) => ({
    key,
    value: String(value ?? "").trim(),
  }))

  const { error } = await supabase.from("settings").upsert(entries, {
    onConflict: "key",
  })

  if (error) return { ok: false, error: error.message }

  revalidatePath("/", "layout")
  return { ok: true }
}
