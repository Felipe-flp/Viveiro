import Link from "next/link"
import { notFound } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { ProductForm } from "@/components/admin/product-form"
import { ChevronLeft } from "lucide-react"
import type { Product } from "@/lib/types"

export default async function EditarProdutoPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()
  const [{ data: product }, { data: categories }] = await Promise.all([
    supabase.from("products").select("*").eq("id", id).single(),
    supabase.from("categories").select("*").order("name"),
  ])
  if (!product) notFound()

  return (
    <div className="space-y-6">
      <Link
        href="/admin/produtos"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ChevronLeft className="h-4 w-4" /> Produtos
      </Link>
      <header>
        <h1 className="font-serif text-3xl font-semibold">Editar produto</h1>
        <p className="mt-1 text-sm text-muted-foreground">{product.name}</p>
      </header>
      <ProductForm categories={categories ?? []} product={product as Product} />
    </div>
  )
}
