import Link from "next/link"
import { createClient } from "@/lib/supabase/server"
import { ProductForm } from "@/components/admin/product-form"
import { ChevronLeft } from "lucide-react"

export default async function NovoProdutoPage() {
  const supabase = await createClient()
  const { data: categories } = await supabase
    .from("categories")
    .select("*")
    .order("name")

  return (
    <div className="space-y-6">
      <Link
        href="/admin/produtos"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ChevronLeft className="h-4 w-4" /> Produtos
      </Link>
      <header>
        <h1 className="font-serif text-3xl font-semibold">Novo produto</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Preencha as informações do produto.
        </p>
      </header>
      <ProductForm categories={categories ?? []} />
    </div>
  )
}
