import Link from "next/link"
import Image from "next/image"
import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import { formatBRL } from "@/lib/format"
import { Plus, Leaf, Pencil } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { ProductDeleteButton } from "@/components/admin/product-delete-button"
import type { Product } from "@/lib/types"

export default async function AdminProdutosPage() {
  const supabase = await createClient()
  const { data } = await supabase
    .from("products")
    .select("*, categories(*)")
    .order("created_at", { ascending: false })

  const products = (data ?? []) as Product[]

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-medium uppercase tracking-wider text-primary">
            Catálogo
          </p>
          <h1 className="font-serif text-3xl font-semibold">Produtos</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {products.length} {products.length === 1 ? "produto" : "produtos"} cadastrados
          </p>
        </div>
        <Button asChild>
          <Link href="/admin/produtos/novo">
            <Plus className="mr-1 h-4 w-4" />
            Novo produto
          </Link>
        </Button>
      </header>

      {products.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border bg-card p-12 text-center">
          <Leaf className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
          <p className="font-serif text-lg">Nenhum produto cadastrado</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Comece criando o primeiro produto.
          </p>
          <Button asChild className="mt-4">
            <Link href="/admin/produtos/novo">Criar produto</Link>
          </Button>
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-border bg-card">
          <ul className="divide-y divide-border">
            {products.map((p) => (
              <li
                key={p.id}
                className="flex flex-wrap items-center gap-4 p-4 sm:flex-nowrap"
              >
                <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-md bg-muted">
                  {p.image_url ? (
                    <Image
                      src={p.image_url || "/placeholder.svg"}
                      alt={p.name}
                      fill
                      className="object-cover"
                      sizes="64px"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                      <Leaf className="h-5 w-5" />
                    </div>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="truncate font-medium">{p.name}</p>
                    {!p.active && (
                      <Badge variant="secondary" className="text-xs">
                        Oculto
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {p.categories?.name || "Sem categoria"}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-serif font-semibold text-primary">
                    {formatBRL(p.price)}
                  </p>
                  <p
                    className={`text-xs ${
                      p.quantity === 0
                        ? "text-destructive"
                        : p.quantity <= 3
                          ? "text-accent-foreground"
                          : "text-muted-foreground"
                    }`}
                  >
                    {p.quantity} em estoque
                  </p>
                </div>
                <div className="flex shrink-0 gap-2">
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/admin/produtos/${p.id}`}>
                      <Pencil className="h-3.5 w-3.5" />
                      <span className="sr-only">Editar</span>
                    </Link>
                  </Button>
                  <ProductDeleteButton id={p.id} name={p.name} />
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}
