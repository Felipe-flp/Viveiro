import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { CheckoutForm } from "@/components/checkout-form"
import { getSettings } from "@/lib/settings"

export default async function CheckoutPage() {
  const settings = await getSettings()
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-4xl flex-1 px-4 py-10 md:px-6 md:py-16">
        <header className="mb-8">
          <p className="mb-2 text-sm font-medium uppercase tracking-wider text-primary">
            Finalizar pedido
          </p>
          <h1 className="font-serif text-3xl font-semibold md:text-4xl">
            Confirme seu pedido
          </h1>
          <p className="mt-2 max-w-2xl text-muted-foreground">
            Confirme os itens e seus dados. Vamos enviar seu pedido para nosso
            WhatsApp para combinar a entrega e o pagamento.
          </p>
        </header>
        <CheckoutForm whatsapp={settings.whatsapp || "5534988599082"} />
      </main>
      <SiteFooter />
    </div>
  )
}
