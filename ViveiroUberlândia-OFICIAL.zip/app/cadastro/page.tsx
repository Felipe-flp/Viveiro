import { AuthShell } from "@/components/auth-shell"
import { SignUpForm } from "@/components/sign-up-form"
import Link from "next/link"

export default function CadastroPage() {
  return (
    <AuthShell
      title="Criar conta"
      subtitle="Cadastre-se para acompanhar seus pedidos e receber novidades."
      footer={
        <p className="text-muted-foreground">
          Já tem conta?{" "}
          <Link href="/login" className="font-medium text-primary hover:underline">
            Entrar
          </Link>
        </p>
      }
    >
      <SignUpForm />
    </AuthShell>
  )
}
