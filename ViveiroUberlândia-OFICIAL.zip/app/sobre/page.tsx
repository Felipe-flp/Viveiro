import Image from "next/image"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { WhatsAppFloat } from "@/components/whatsapp-float"
import { getSettings } from "@/lib/settings"
import { Leaf, Award, Users, Sparkles } from "lucide-react"

export default async function SobrePage() {
  const settings = await getSettings()

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="flex-1">
        <section className="mx-auto max-w-7xl px-4 py-12 md:px-6 md:py-20">
          <div className="grid gap-10 md:grid-cols-2 md:gap-16">
            <div className="flex flex-col justify-center gap-6">
              <p className="text-sm font-medium uppercase tracking-wider text-primary">
                Quem somos
              </p>
              <h1 className="font-serif text-4xl font-semibold md:text-5xl">
                Nossa história começa na terra.
              </h1>
              <p className="leading-relaxed text-muted-foreground">
                {settings.about_text ||
                  "O Viveiro Uberlândia Plantas é especializado em mudas, ornamentais, suculentas, cactos, flores e frutíferas. Atendemos com cuidado, oferecendo plantas saudáveis e dicas de cultivo para você ter sempre o melhor da natureza em casa."}
              </p>
              <p className="leading-relaxed text-muted-foreground">
                Acreditamos que cada planta carrega um pedacinho de calma, beleza e
                vida. Por isso selecionamos espécies adaptadas ao nosso clima,
                cultivamos com dedicação e oferecemos orientação para que cada cliente
                encontre a planta certa para seu espaço.
              </p>
            </div>
            <div className="relative aspect-[4/5] overflow-hidden rounded-2xl bg-muted">
              <Image
                src="/images/sobre-viveiro.jpg"
                alt="Viveiro de plantas"
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 50vw"
              />
            </div>
          </div>
        </section>

        <section className="bg-secondary/40 py-16 md:py-24">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="mb-12 text-center">
              <h2 className="font-serif text-3xl font-semibold md:text-4xl">
                Nossos valores
              </h2>
              <p className="mt-2 text-muted-foreground">
                O que guia nosso trabalho todos os dias
              </p>
            </div>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {[
                {
                  icon: Leaf,
                  title: "Plantas saudáveis",
                  desc: "Selecionadas e cultivadas com cuidado para chegar em ótimo estado.",
                },
                {
                  icon: Users,
                  title: "Atendimento próximo",
                  desc: "Conversamos como amigos. Tirar dúvidas é parte do nosso trabalho.",
                },
                {
                  icon: Sparkles,
                  title: "Variedade",
                  desc: "Mais de 200 espécies entre ornamentais, suculentas, frutíferas e flores.",
                },
                {
                  icon: Award,
                  title: "Qualidade local",
                  desc: "Trabalhamos com produtores parceiros da região do Triângulo Mineiro.",
                },
              ].map((v) => (
                <div
                  key={v.title}
                  className="rounded-xl border border-border bg-card p-6"
                >
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <v.icon className="h-5 w-5" />
                  </span>
                  <h3 className="mt-4 font-serif text-lg font-semibold">
                    {v.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {v.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
      <WhatsAppFloat phone={settings.whatsapp || "5534988599082"} />
    </div>
  )
}
