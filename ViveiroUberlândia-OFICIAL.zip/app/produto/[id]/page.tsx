import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { WhatsAppFloat } from "@/components/whatsapp-float"
import { ProductActions } from "@/components/product-actions"
import { createClient } from "@/lib/supabase/server"
import { getSettings } from "@/lib/settings"
import { formatBRL } from "@/lib/format"
import type { Product } from "@/lib/types"
import { Leaf, Truck, ShieldCheck, ChevronRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export default async function ProductPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()
  const { data } = await supabase
    .from("products")
    .select("*, categories(*)")
    .eq("id", id)
    .eq("active", true)
    .single()

  if (!data) return notFound()
  const product = data as Product
  const settings = await getSettings()
  const outOfStock = product.quantity <= 0

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 md:px-6 md:py-12">
        <nav className="mb-6 flex flex-wrap items-center gap-1 text-sm text-muted-foreground">
          <Link href="/" className="hover:text-foreground">
            Início
          </Link>
          <ChevronRight className="h-3.5 w-3.5" />
          <Link href="/estoque" className="hover:text-foreground">
            Estoque
          </Link>
          {product.categories && (
            <>
              <ChevronRight className="h-3.5 w-3.5" />
              <Link
                href={`/estoque?categoria=${product.categories.slug}`}
                className="hover:text-foreground"
              >
                {product.categories.name}
              </Link>
            </>
          )}
          <ChevronRight className="h-3.5 w-3.5" />
          <span className="line-clamp-1 text-foreground">{product.name}</span>
        </nav>

        <div className="grid gap-8 md:grid-cols-2 md:gap-12">
          <div className="relative aspect-square overflow-hidden rounded-2xl bg-muted">
            {product.image_url ? (
              <Image
                src={product.image_url || "/placeholder.svg"}
                alt={product.name}
                fill
                priority
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 50vw"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center">
                <Leaf className="h-16 w-16 text-muted-foreground" />
              </div>
            )}
            {outOfStock && (
              <Badge className="absolute left-4 top-4 bg-destructive text-destructive-foreground">
                Esgotado
              </Badge>
            )}
          </div>

          <div className="flex flex-col gap-6">
            <div>
              {product.categories && (
                <p className="mb-2 text-sm font-medium uppercase tracking-wider text-primary">
                  {product.categories.name}
                </p>
              )}
              <h1 className="font-serif text-3xl font-semibold md:text-4xl">
                {product.name}
              </h1>
            </div>

            <p className="font-serif text-4xl font-semibold text-primary">
              {formatBRL(product.price)}
            </p>

            {product.description && (
              <div className="prose prose-sm max-w-none text-muted-foreground">
                <p className="whitespace-pre-line leading-relaxed">
                  {product.description}
                </p>
              </div>
            )}

            <div className="flex items-center gap-3 text-sm">
              <span className="text-muted-foreground">Disponibilidade:</span>
              {outOfStock ? (
                <span className="font-medium text-destructive">Sem estoque</span>
              ) : (
                <span className="font-medium text-primary">
                  {product.quantity} {product.quantity === 1 ? "unidade" : "unidades"} em estoque
                </span>
              )}
            </div>

            <ProductActions product={product} />

            <div className="grid gap-3 rounded-xl border border-border bg-card p-4 text-sm">
              <div className="flex items-start gap-3">
                <Truck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <div>
                  <p className="font-medium">Entrega em Uberlândia</p>
                  <p className="text-muted-foreground">
                    Combinamos a entrega via WhatsApp após o pedido.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <div>
                  <p className="font-medium">Plantas saudáveis</p>
                  <p className="text-muted-foreground">
                    Cuidamos para que cheguem em ótimo estado até você.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <SiteFooter />
      <WhatsAppFloat phone={settings.whatsapp || "5534988599082"} />
    </div>
  )
}
