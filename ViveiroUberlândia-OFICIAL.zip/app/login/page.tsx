import { AuthShell } from "@/components/auth-shell"
import { LoginForm } from "@/components/login-form"
import Link from "next/link"

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ redirect?: string }>
}) {
  const params = await searchParams
  return (
    <AuthShell
      title="Bem-vindo de volta"
      subtitle="Entre para acompanhar seus pedidos e finalizar suas compras."
      footer={
        <p className="text-muted-foreground">
          Ainda não tem conta?{" "}
          <Link href="/cadastro" className="font-medium text-primary hover:underline">
            Criar conta
          </Link>
        </p>
      }
    >
      <LoginForm redirect={params.redirect} />
    </AuthShell>
  )
}
