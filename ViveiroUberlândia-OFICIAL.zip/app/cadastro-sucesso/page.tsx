import { AuthShell } from "@/components/auth-shell"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Mail } from "lucide-react"

export default function CadastroSucessoPage() {
  return (
    <AuthShell
      title="Confira seu e-mail"
      subtitle="Enviamos um link de confirmação para o e-mail que você cadastrou."
    >
      <div className="rounded-xl border border-border bg-card p-6 text-center">
        <span className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
          <Mail className="h-6 w-6" />
        </span>
        <p className="text-sm text-muted-foreground">
          Clique no link enviado por e-mail para ativar sua conta. Depois disso, você
          pode fazer login normalmente.
        </p>
      </div>
      <Button asChild className="mt-6 w-full" size="lg" variant="outline">
        <Link href="/login">Ir para o login</Link>
      </Button>
    </AuthShell>
  )
}
