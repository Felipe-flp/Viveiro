import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { WhatsAppFloat } from "@/components/whatsapp-float"
import { Button } from "@/components/ui/button"
import { getSettings } from "@/lib/settings"
import { MessageCircle, Instagram, Mail, MapPin, Clock } from "lucide-react"

export default async function ContatoPage() {
  const settings = await getSettings()
  const whatsapp = settings.whatsapp || "5534988599082"
  const instagram = settings.instagram || "uberlandia.plantas"
  const address = settings.address || "Uberlândia, MG"
  const email = settings.email_contato || "contato@viveirouberlandia.com.br"
  const horario = settings.horario || "Seg a Sáb: 8h às 18h | Domingo: 8h às 12h"

  const message = encodeURIComponent(
    "Olá! Encontrei o Viveiro Uberlândia pelo site e gostaria de mais informações.",
  )

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />

      <main className="flex-1">
        <section className="mx-auto max-w-7xl px-4 py-12 md:px-6 md:py-20">
          <div className="mb-10 text-center">
            <p className="mb-2 text-sm font-medium uppercase tracking-wider text-primary">
              Fale com a gente
            </p>
            <h1 className="font-serif text-4xl font-semibold md:text-5xl">
              Estamos por aqui para te ajudar
            </h1>
            <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
              Tire dúvidas, peça orientações de cultivo ou faça seu pedido. A gente
              adora conversar sobre plantas.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <div className="rounded-2xl border border-border bg-card p-8">
              <h2 className="font-serif text-2xl font-semibold">
                Atendimento direto
              </h2>
              <p className="mt-2 text-muted-foreground">
                A forma mais rápida de falar com a gente é pelo WhatsApp.
              </p>
              <div className="mt-6 flex flex-col gap-3">
                <Button asChild size="lg" className="w-full justify-start">
                  <a
                    href={`https://wa.me/${whatsapp}?text=${message}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <MessageCircle className="mr-2 h-5 w-5" />
                    Abrir conversa no WhatsApp
                  </a>
                </Button>
                <Button asChild size="lg" variant="outline" className="w-full justify-start">
                  <a
                    href={`https://instagram.com/${instagram}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Instagram className="mr-2 h-5 w-5" />
                    Seguir no Instagram
                  </a>
                </Button>
                <Button asChild size="lg" variant="outline" className="w-full justify-start">
                  <a href={`mailto:${email}`}>
                    <Mail className="mr-2 h-5 w-5" />
                    Enviar e-mail
                  </a>
                </Button>
              </div>
            </div>

            <div className="rounded-2xl bg-sidebar p-8 text-sidebar-foreground">
              <h2 className="font-serif text-2xl font-semibold">Visite o viveiro</h2>
              <p className="mt-2 text-sidebar-foreground/70">
                Venha conhecer pessoalmente as plantas. Vai ser um prazer te receber.
              </p>
              <ul className="mt-6 space-y-4 text-sm">
                <li className="flex items-start gap-3">
                  <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-sidebar-primary" />
                  <div>
                    <p className="font-medium text-sidebar-foreground">Endereço</p>
                    <p className="text-sidebar-foreground/70">{address}</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <Clock className="mt-0.5 h-5 w-5 shrink-0 text-sidebar-primary" />
                  <div>
                    <p className="font-medium text-sidebar-foreground">
                      Horário de funcionamento
                    </p>
                    <p className="text-sidebar-foreground/70">{horario}</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <MessageCircle className="mt-0.5 h-5 w-5 shrink-0 text-sidebar-primary" />
                  <div>
                    <p className="font-medium text-sidebar-foreground">WhatsApp</p>
                    <p className="text-sidebar-foreground/70">
                      +55 {whatsapp.slice(2, 4)} {whatsapp.slice(4, 9)}-
                      {whatsapp.slice(9)}
                    </p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 pb-16 md:px-6 md:pb-24">
          <div className="overflow-hidden rounded-2xl border border-border">
            <iframe
              title="Mapa - Uberlândia"
              src={`https://www.google.com/maps?q=${encodeURIComponent(address)}&output=embed`}
              className="h-[400px] w-full"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </section>
      </main>

      <SiteFooter />
      <WhatsAppFloat phone={whatsapp} />
    </div>
  )
}
