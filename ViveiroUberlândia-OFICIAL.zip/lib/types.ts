export type Profile = {
  id: string
  full_name: string | null
  email: string | null
  role: "user" | "admin" | "super_admin"
  must_change_password: boolean
  created_at: string
  updated_at: string
}

export type Category = {
  id: string
  name: string
  slug: string
  created_at: string
}

export type Product = {
  id: string
  name: string
  description: string | null
  price: number
  quantity: number
  image_url: string | null
  category_id: string | null
  active: boolean
  created_at: string
  updated_at: string
  categories?: Category | null
}

export type OrderStatus = "pending" | "confirmed" | "delivered" | "cancelled"

export type Order = {
  id: string
  user_id: string | null
  customer_name: string | null
  customer_phone: string | null
  total: number
  status: OrderStatus
  whatsapp_message: string | null
  created_at: string
  updated_at: string
}

export type OrderItem = {
  id: string
  order_id: string
  product_id: string | null
  product_name: string
  unit_price: number
  quantity: number
  subtotal: number
}

export type CartItem = {
  product_id: string
  name: string
  price: number
  image_url: string | null
  quantity: number
  max_quantity: number
}

export type SettingsMap = Record<string, string>
