import { createClient } from "@/lib/supabase/server"
import type { SettingsMap } from "./types"

export async function getSettings(): Promise<SettingsMap> {
  const supabase = await createClient()
  const { data } = await supabase.from("settings").select("key, value")
  const map: SettingsMap = {}
  for (const row of data ?? []) {
    if (row.value != null) map[row.key] = row.value
  }
  return map
}
