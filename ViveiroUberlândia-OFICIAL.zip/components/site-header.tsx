"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Logo } from "./logo"
import { Button } from "./ui/button"
import { Sheet, SheetContent, SheetTrigger, SheetTitle, SheetDescription } from "./ui/sheet"
import { Menu, ShoppingBag, User, LogOut, ShieldCheck } from "lucide-react"
import { useCart } from "./cart-provider"
import { Badge } from "./ui/badge"
import { CartDrawer } from "./cart-drawer"
import { createClient } from "@/lib/supabase/client"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"

const navLinks = [
  { href: "/", label: "Início" },
  { href: "/estoque", label: "Estoque" },
  { href: "/sobre", label: "Sobre" },
  { href: "/contato", label: "Contato" },
]

type SessionInfo = {
  email: string
  full_name: string | null
  role: "user" | "admin" | "super_admin"
} | null

export function SiteHeader() {
  const { totalItems, setOpen } = useCart()
  const [session, setSession] = useState<SessionInfo>(null)
  const [open, setMobileOpen] = useState(false)
  const pathname = usePathname()
  const router = useRouter()

  useEffect(() => {
    const supabase = createClient()
    let active = true

    async function load() {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        if (active) setSession(null)
        return
      }
      const { data: profile } = await supabase
        .from("profiles")
        .select("email, full_name, role")
        .eq("id", user.id)
        .single()
      if (active && profile) {
        setSession({
          email: profile.email ?? user.email ?? "",
          full_name: profile.full_name,
          role: profile.role,
        })
      }
    }

    load()
    const { data: sub } = supabase.auth.onAuthStateChange(() => load())
    return () => {
      active = false
      sub.subscription.unsubscribe()
    }
  }, [])

  async function handleLogout() {
    const supabase = createClient()
    await supabase.auth.signOut()
    setSession(null)
    router.refresh()
    router.push("/")
  }

  const isAdmin = session?.role === "admin" || session?.role === "super_admin"

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 md:px-6">
        <div className="flex items-center gap-6">
          <Logo />
          <nav className="hidden items-center gap-1 md:flex">
            {navLinks.map((link) => {
              const active = pathname === link.href
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                    active
                      ? "bg-secondary text-secondary-foreground"
                      : "text-foreground/70 hover:text-foreground hover:bg-secondary/60"
                  }`}
                >
                  {link.label}
                </Link>
              )
            })}
          </nav>
        </div>

        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setOpen(true)}
            aria-label="Abrir carrinho"
            className="relative"
          >
            <ShoppingBag className="h-5 w-5" />
            {totalItems > 0 && (
              <Badge className="absolute -right-1 -top-1 h-5 min-w-5 rounded-full bg-accent px-1 text-[10px] text-accent-foreground">
                {totalItems}
              </Badge>
            )}
          </Button>

          {session ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Conta">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium">
                      {session.full_name || "Cliente"}
                    </span>
                    <span className="truncate text-xs text-muted-foreground">
                      {session.email}
                    </span>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/minha-conta">Minha conta</Link>
                </DropdownMenuItem>
                {isAdmin && (
                  <DropdownMenuItem asChild>
                    <Link href="/admin" className="flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4" />
                      Painel Admin
                    </Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Sair
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button asChild variant="ghost" size="sm" className="hidden md:inline-flex">
              <Link href="/login">Entrar</Link>
            </Button>
          )}

          <Sheet open={open} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                aria-label="Abrir menu"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[280px]">
              <SheetTitle className="sr-only">Menu de navegação</SheetTitle>
              <SheetDescription className="sr-only">
                Links principais do site
              </SheetDescription>
              <div className="flex flex-col gap-2 pt-8">
                {navLinks.map((link) => (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className={`rounded-md px-3 py-3 text-base font-medium transition-colors ${
                      pathname === link.href
                        ? "bg-secondary text-secondary-foreground"
                        : "text-foreground/80 hover:bg-secondary/60"
                    }`}
                  >
                    {link.label}
                  </Link>
                ))}
                <div className="mt-4 border-t border-border pt-4">
                  {session ? (
                    <>
                      <Link
                        href="/minha-conta"
                        onClick={() => setMobileOpen(false)}
                        className="block rounded-md px-3 py-3 text-base font-medium text-foreground/80 hover:bg-secondary/60"
                      >
                        Minha conta
                      </Link>
                      {isAdmin && (
                        <Link
                          href="/admin"
                          onClick={() => setMobileOpen(false)}
                          className="block rounded-md px-3 py-3 text-base font-medium text-foreground/80 hover:bg-secondary/60"
                        >
                          Painel Admin
                        </Link>
                      )}
                      <button
                        onClick={() => {
                          setMobileOpen(false)
                          handleLogout()
                        }}
                        className="block w-full rounded-md px-3 py-3 text-left text-base font-medium text-foreground/80 hover:bg-secondary/60"
                      >
                        Sair
                      </button>
                    </>
                  ) : (
                    <Link
                      href="/login"
                      onClick={() => setMobileOpen(false)}
                      className="block rounded-md px-3 py-3 text-base font-medium text-foreground/80 hover:bg-secondary/60"
                    >
                      Entrar / Criar conta
                    </Link>
                  )}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      <CartDrawer />
    </header>
  )
}
