"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "../ui/button"
import { Input } from "../ui/input"
import { Field, FieldLabel, FieldGroup, FieldError } from "../ui/field"
import { Spinner } from "../ui/spinner"
import { toast } from "sonner"

export function ChangePasswordForm({ forced }: { forced: boolean }) {
  const router = useRouter()
  const [password, setPassword] = useState("")
  const [confirm, setConfirm] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    if (password.length < 8) {
      setError("A nova senha precisa ter pelo menos 8 caracteres.")
      return
    }
    if (password !== confirm) {
      setError("As senhas não coincidem.")
      return
    }
    setLoading(true)
    try {
      const supabase = createClient()
      const { error: updateError } = await supabase.auth.updateUser({ password })
      if (updateError) {
        setError(updateError.message)
        setLoading(false)
        return
      }
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (user) {
        await supabase
          .from("profiles")
          .update({ must_change_password: false })
          .eq("id", user.id)
      }
      toast.success("Senha alterada com sucesso!")
      router.push("/admin")
      router.refresh()
    } catch (err) {
      setError("Erro inesperado. Tente novamente.")
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      <FieldGroup>
        <Field>
          <FieldLabel htmlFor="password">Nova senha</FieldLabel>
          <Input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="new-password"
            minLength={8}
          />
        </Field>
        <Field>
          <FieldLabel htmlFor="confirm">Confirmar nova senha</FieldLabel>
          <Input
            id="confirm"
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            required
            autoComplete="new-password"
            minLength={8}
          />
        </Field>
        {error && <FieldError>{error}</FieldError>}
        <Button type="submit" size="lg" disabled={loading} className="w-full">
          {loading ? (
            <>
              <Spinner /> Salvando...
            </>
          ) : (
            "Salvar nova senha"
          )}
        </Button>
        {!forced && (
          <Button
            type="button"
            variant="ghost"
            className="w-full"
            onClick={() => router.push("/admin")}
          >
            Cancelar
          </Button>
        )}
      </FieldGroup>
    </form>
  )
}
