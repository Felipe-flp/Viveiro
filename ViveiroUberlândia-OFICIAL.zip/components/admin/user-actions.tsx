"use client"

import { useState, useTransition } from "react"
import { Button } from "../ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../ui/alert-dialog"
import { Input } from "../ui/input"
import { Field, FieldLabel, FieldGroup, FieldError } from "../ui/field"
import { Spinner } from "../ui/spinner"
import { MoreVertical, Key, Trash2 } from "lucide-react"
import {
  removeAdminAction,
  resetAdminPasswordAction,
} from "@/app/admin/usuarios/actions"
import { toast } from "sonner"

export function UserActions({ userId, email }: { userId: string; email: string }) {
  const [resetOpen, setResetOpen] = useState(false)
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [pending, startTransition] = useTransition()
  const [newPassword, setNewPassword] = useState("")
  const [error, setError] = useState<string | null>(null)

  function handleReset(formData: FormData) {
    setError(null)
    formData.set("user_id", userId)
    startTransition(async () => {
      const result = await resetAdminPasswordAction(formData)
      if (!result.ok) {
        setError(result.error || "Erro.")
        return
      }
      toast.success("Senha redefinida! Compartilhe com o usuário.")
      setResetOpen(false)
      setNewPassword("")
    })
  }

  function handleDelete() {
    const fd = new FormData()
    fd.set("user_id", userId)
    startTransition(async () => {
      const result = await removeAdminAction(fd)
      if (!result.ok) {
        toast.error(result.error || "Erro ao remover.")
        return
      }
      toast.success("Admin removido.")
      setDeleteOpen(false)
    })
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" aria-label="Opções">
            <MoreVertical className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => setResetOpen(true)}>
            <Key className="mr-2 h-4 w-4" />
            Redefinir senha
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={() => setDeleteOpen(true)}
            className="text-destructive focus:text-destructive"
          >
            <Trash2 className="mr-2 h-4 w-4" />
            Remover admin
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={resetOpen} onOpenChange={setResetOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Redefinir senha</DialogTitle>
            <DialogDescription>
              Defina uma nova senha temporária para {email}. O admin será forçado a
              trocá-la no próximo login.
            </DialogDescription>
          </DialogHeader>
          <form action={handleReset}>
            <FieldGroup>
              <Field>
                <FieldLabel htmlFor="password">Nova senha temporária</FieldLabel>
                <Input
                  id="password"
                  name="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  minLength={8}
                />
              </Field>
              {error && <FieldError>{error}</FieldError>}
            </FieldGroup>
            <DialogFooter className="mt-4">
              <Button
                type="button"
                variant="ghost"
                onClick={() => setResetOpen(false)}
              >
                Cancelar
              </Button>
              <Button type="submit" disabled={pending}>
                {pending ? <Spinner /> : "Redefinir"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remover admin?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação remove permanentemente {email} do sistema.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={pending}
              className="bg-destructive text-destructive-foreground hover:opacity-90"
            >
              Remover
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
