"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { createClient } from "@/lib/supabase/client"
import { Button } from "../ui/button"
import { Input } from "../ui/input"
import { Textarea } from "../ui/textarea"
import { Switch } from "../ui/switch"
import {
  Field,
  FieldLabel,
  FieldGroup,
  FieldError,
  FieldDescription,
} from "../ui/field"
import { Spinner } from "../ui/spinner"
import { toast } from "sonner"
import { Upload, Trash2, ImageIcon } from "lucide-react"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select"
import type { Category, Product } from "@/lib/types"

export function ProductForm({
  categories,
  product,
}: {
  categories: Category[]
  product?: Product
}) {
  const router = useRouter()
  const isEdit = !!product

  const [name, setName] = useState(product?.name ?? "")
  const [description, setDescription] = useState(product?.description ?? "")
  const [price, setPrice] = useState(product?.price?.toString() ?? "")
  const [quantity, setQuantity] = useState(product?.quantity?.toString() ?? "0")
  const [categoryId, setCategoryId] = useState(product?.category_id ?? "")
  const [active, setActive] = useState(product?.active ?? true)
  const [imageUrl, setImageUrl] = useState(product?.image_url ?? "")
  const [uploading, setUploading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Imagem muito grande. Máx 5MB.")
      return
    }
    setUploading(true)
    try {
      const supabase = createClient()
      const ext = file.name.split(".").pop()
      const path = `products/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`
      const { error: uploadError } = await supabase.storage
        .from("products")
        .upload(path, file, { upsert: false, cacheControl: "3600" })
      if (uploadError) {
        toast.error("Erro ao enviar imagem: " + uploadError.message)
        return
      }
      const { data } = supabase.storage.from("products").getPublicUrl(path)
      setImageUrl(data.publicUrl)
      toast.success("Imagem enviada!")
    } catch (err) {
      toast.error("Erro ao enviar imagem.")
    } finally {
      setUploading(false)
      // reset input
      e.target.value = ""
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    if (!name.trim()) {
      setError("Informe o nome do produto.")
      return
    }
    const priceNum = Number(price.replace(",", "."))
    if (isNaN(priceNum) || priceNum < 0) {
      setError("Preço inválido.")
      return
    }
    const qtyNum = Number(quantity)
    if (isNaN(qtyNum) || qtyNum < 0) {
      setError("Quantidade inválida.")
      return
    }

    setSaving(true)
    try {
      const supabase = createClient()
      const payload = {
        name: name.trim(),
        description: description.trim() || null,
        price: priceNum,
        quantity: Math.floor(qtyNum),
        category_id: categoryId || null,
        active,
        image_url: imageUrl || null,
      }

      if (isEdit && product) {
        const { error: updateError } = await supabase
          .from("products")
          .update(payload)
          .eq("id", product.id)
        if (updateError) {
          setError(updateError.message)
          setSaving(false)
          return
        }
        toast.success("Produto atualizado!")
      } else {
        const { error: insertError } = await supabase
          .from("products")
          .insert(payload)
        if (insertError) {
          setError(insertError.message)
          setSaving(false)
          return
        }
        toast.success("Produto criado!")
      }
      router.push("/admin/produtos")
      router.refresh()
    } catch (err) {
      setError("Erro inesperado.")
      setSaving(false)
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="grid gap-6 md:grid-cols-[1fr_320px]"
    >
      <div className="rounded-xl border border-border bg-card p-6">
        <FieldGroup>
          <Field>
            <FieldLabel htmlFor="name">Nome do produto</FieldLabel>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </Field>
          <Field>
            <FieldLabel htmlFor="description">Descrição</FieldLabel>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={5}
              placeholder="Conte sobre a planta, cuidados, tamanho do vaso..."
            />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field>
              <FieldLabel htmlFor="price">Preço (R$)</FieldLabel>
              <Input
                id="price"
                inputMode="decimal"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="0,00"
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="quantity">Quantidade em estoque</FieldLabel>
              <Input
                id="quantity"
                inputMode="numeric"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                required
              />
            </Field>
          </div>
          <Field>
            <FieldLabel>Categoria</FieldLabel>
            <Select value={categoryId} onValueChange={setCategoryId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          {error && <FieldError>{error}</FieldError>}
        </FieldGroup>
      </div>

      <div className="space-y-6">
        <div className="rounded-xl border border-border bg-card p-6">
          <h3 className="font-serif text-lg font-semibold">Imagem</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            Tamanho máximo: 5MB. JPG ou PNG.
          </p>

          <div className="mt-4 aspect-square overflow-hidden rounded-md border border-border bg-muted">
            {imageUrl ? (
              <Image
                src={imageUrl || "/placeholder.svg"}
                alt="Preview"
                width={400}
                height={400}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full items-center justify-center text-muted-foreground">
                <ImageIcon className="h-10 w-10" />
              </div>
            )}
          </div>

          <div className="mt-4 flex flex-col gap-2">
            <label
              htmlFor="image"
              className="inline-flex cursor-pointer items-center justify-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition hover:opacity-90"
            >
              {uploading ? <Spinner /> : <Upload className="h-4 w-4" />}
              {imageUrl ? "Trocar imagem" : "Enviar imagem"}
            </label>
            <input
              id="image"
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              disabled={uploading}
              className="sr-only"
            />
            {imageUrl && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setImageUrl("")}
              >
                <Trash2 className="mr-1 h-3.5 w-3.5" />
                Remover imagem
              </Button>
            )}
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-6">
          <Field orientation="horizontal">
            <div className="flex-1">
              <FieldLabel htmlFor="active">Produto visível no site</FieldLabel>
              <FieldDescription>
                Desative para ocultar do catálogo público.
              </FieldDescription>
            </div>
            <Switch id="active" checked={active} onCheckedChange={setActive} />
          </Field>
        </div>

        <Button type="submit" size="lg" disabled={saving} className="w-full">
          {saving ? (
            <>
              <Spinner /> Salvando...
            </>
          ) : isEdit ? (
            "Salvar alterações"
          ) : (
            "Criar produto"
          )}
        </Button>
      </div>
    </form>
  )
}
