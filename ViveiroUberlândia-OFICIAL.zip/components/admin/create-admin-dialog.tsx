"use client"

import { useState, useTransition } from "react"
import { Button } from "../ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../ui/dialog"
import { Input } from "../ui/input"
import { Field, FieldLabel, FieldGroup, FieldError, FieldDescription } from "../ui/field"
import { Spinner } from "../ui/spinner"
import { Plus, RotateCcw } from "lucide-react"
import { createAdminAction } from "@/app/admin/usuarios/actions"
import { toast } from "sonner"

function generatePassword() {
  const chars = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"
  let pw = ""
  for (let i = 0; i < 10; i++) pw += chars[Math.floor(Math.random() * chars.length)]
  return pw
}

export function CreateAdminDialog() {
  const [open, setOpen] = useState(false)
  const [pending, startTransition] = useTransition()
  const [password, setPassword] = useState(generatePassword())
  const [error, setError] = useState<string | null>(null)

  function handleSubmit(formData: FormData) {
    setError(null)
    startTransition(async () => {
      const result = await createAdminAction(formData)
      if (!result.ok) {
        setError(result.error || "Erro ao criar admin.")
        return
      }
      toast.success("Admin criado! Compartilhe a senha temporária.")
      setOpen(false)
      setPassword(generatePassword())
    })
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-1 h-4 w-4" />
          Novo admin
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Criar novo admin</DialogTitle>
          <DialogDescription>
            O admin precisará trocar a senha no primeiro login.
          </DialogDescription>
        </DialogHeader>
        <form action={handleSubmit} className="space-y-4">
          <FieldGroup>
            <Field>
              <FieldLabel htmlFor="full_name">Nome completo</FieldLabel>
              <Input id="full_name" name="full_name" required />
            </Field>
            <Field>
              <FieldLabel htmlFor="email">E-mail</FieldLabel>
              <Input id="email" name="email" type="email" required />
            </Field>
            <Field>
              <FieldLabel htmlFor="password">Senha temporária</FieldLabel>
              <div className="flex gap-2">
                <Input
                  id="password"
                  name="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={8}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => setPassword(generatePassword())}
                  aria-label="Gerar nova senha"
                >
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
              <FieldDescription>
                Compartilhe esta senha com o admin. Ele será obrigado a trocá-la
                no primeiro login.
              </FieldDescription>
            </Field>
            {error && <FieldError>{error}</FieldError>}
          </FieldGroup>
          <DialogFooter>
            <Button
              type="button"
              variant="ghost"
              onClick={() => setOpen(false)}
            >
              Cancelar
            </Button>
            <Button type="submit" disabled={pending}>
              {pending ? <Spinner /> : "Criar admin"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
