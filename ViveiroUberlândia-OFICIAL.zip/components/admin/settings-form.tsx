"use client"

import { useState, useTransition } from "react"
import { Button } from "../ui/button"
import { Input } from "../ui/input"
import { Textarea } from "../ui/textarea"
import { Field, FieldLabel, FieldGroup, FieldDescription, FieldError } from "../ui/field"
import { Spinner } from "../ui/spinner"
import { saveSettingsAction } from "@/app/admin/configuracoes/actions"
import { toast } from "sonner"
import type { SettingsMap } from "@/lib/types"

const FIELDS: {
  key: string
  label: string
  description?: string
  type?: "text" | "textarea"
  placeholder?: string
}[] = [
  {
    key: "whatsapp",
    label: "WhatsApp",
    description: "Apenas números, com DDI e DDD. Ex: 5534988599082",
    placeholder: "5534988599082",
  },
  {
    key: "instagram",
    label: "Instagram",
    description: "Apenas o usuário, sem @. Ex: uberlandia.plantas",
    placeholder: "uberlandia.plantas",
  },
  {
    key: "email_contato",
    label: "E-mail de contato",
    placeholder: "contato@viveirouberlandia.com.br",
  },
  {
    key: "address",
    label: "Endereço",
    placeholder: "Rua das Flores, 123 - Bairro - Uberlândia, MG",
  },
  {
    key: "horario",
    label: "Horário de funcionamento",
    placeholder: "Seg a Sáb: 8h às 18h",
  },
  { key: "site_subtitle", label: "Subtítulo / chamada principal" },
  {
    key: "hero_text",
    label: "Texto da home",
    type: "textarea",
  },
  { key: "about_text", label: "Texto sobre o viveiro", type: "textarea" },
]

export function SettingsForm({ initial }: { initial: SettingsMap }) {
  const [values, setValues] = useState<SettingsMap>(initial)
  const [pending, startTransition] = useTransition()
  const [error, setError] = useState<string | null>(null)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    const fd = new FormData()
    for (const [k, v] of Object.entries(values)) fd.set(k, v ?? "")
    startTransition(async () => {
      const result = await saveSettingsAction(fd)
      if (!result.ok) {
        setError(result.error || "Erro ao salvar.")
        return
      }
      toast.success("Configurações atualizadas!")
    })
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-4 md:grid-cols-2">
      {FIELDS.map((f) => (
        <Field
          key={f.key}
          className={f.type === "textarea" ? "md:col-span-2" : undefined}
        >
          <FieldLabel htmlFor={f.key}>{f.label}</FieldLabel>
          {f.type === "textarea" ? (
            <Textarea
              id={f.key}
              value={values[f.key] ?? ""}
              onChange={(e) =>
                setValues((prev) => ({ ...prev, [f.key]: e.target.value }))
              }
              rows={4}
              placeholder={f.placeholder}
            />
          ) : (
            <Input
              id={f.key}
              value={values[f.key] ?? ""}
              onChange={(e) =>
                setValues((prev) => ({ ...prev, [f.key]: e.target.value }))
              }
              placeholder={f.placeholder}
            />
          )}
          {f.description && <FieldDescription>{f.description}</FieldDescription>}
        </Field>
      ))}
      {error && <FieldError className="md:col-span-2">{error}</FieldError>}
      <div className="md:col-span-2">
        <Button type="submit" size="lg" disabled={pending}>
          {pending ? (
            <>
              <Spinner /> Salvando...
            </>
          ) : (
            "Salvar configurações"
          )}
        </Button>
      </div>
    </form>
  )
}
