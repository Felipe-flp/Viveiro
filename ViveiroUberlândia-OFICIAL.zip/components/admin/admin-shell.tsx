"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useState } from "react"
import {
  LayoutDashboard,
  Package,
  ClipboardList,
  Users,
  Settings,
  Menu,
  LogOut,
  Leaf,
  ExternalLink,
} from "lucide-react"
import { Button } from "../ui/button"
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "../ui/sheet"
import { createClient } from "@/lib/supabase/client"

type Profile = {
  full_name: string | null
  email: string
  role: "admin" | "super_admin" | "user"
}

const NAV = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { href: "/admin/produtos", label: "Produtos", icon: Package },
  { href: "/admin/pedidos", label: "Pedidos", icon: ClipboardList },
  { href: "/admin/usuarios", label: "Usuários", icon: Users, superOnly: true },
  { href: "/admin/configuracoes", label: "Configurações", icon: Settings },
]

export function AdminShell({
  profile,
  children,
}: {
  profile: Profile
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const router = useRouter()
  const [open, setOpen] = useState(false)

  async function handleLogout() {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push("/")
    router.refresh()
  }

  const items = NAV.filter((n) => !n.superOnly || profile.role === "super_admin")

  function NavList({ onItemClick }: { onItemClick?: () => void }) {
    return (
      <nav className="flex flex-col gap-1 p-3">
        {items.map((n) => {
          const active = n.exact ? pathname === n.href : pathname.startsWith(n.href)
          return (
            <Link
              key={n.href}
              href={n.href}
              onClick={onItemClick}
              className={`flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition ${
                active
                  ? "bg-sidebar-accent text-sidebar-foreground"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground"
              }`}
            >
              <n.icon className="h-4 w-4" />
              {n.label}
            </Link>
          )
        })}
      </nav>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="flex">
        {/* Desktop sidebar */}
        <aside className="hidden w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground md:flex md:min-h-screen md:sticky md:top-0">
          <div className="flex items-center gap-2 px-5 py-5">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-sidebar-primary text-sidebar-primary-foreground">
              <Leaf className="h-5 w-5" />
            </span>
            <div>
              <p className="font-serif text-base font-semibold leading-tight">Painel</p>
              <p className="text-xs uppercase tracking-widest text-sidebar-foreground/60">
                Viveiro UDI
              </p>
            </div>
          </div>
          <NavList />
          <div className="mt-auto border-t border-sidebar-border p-3">
            <div className="rounded-md px-3 py-2 text-xs">
              <p className="font-medium text-sidebar-foreground">
                {profile.full_name || "Admin"}
              </p>
              <p className="truncate text-sidebar-foreground/60">{profile.email}</p>
              <p className="mt-1 inline-block rounded-full bg-sidebar-primary/20 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-sidebar-primary">
                {profile.role === "super_admin" ? "Super Admin" : "Admin"}
              </p>
            </div>
            <Link
              href="/"
              className="mt-2 flex items-center gap-2 rounded-md px-3 py-2 text-sm text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground"
            >
              <ExternalLink className="h-4 w-4" />
              Ver site
            </Link>
            <button
              onClick={handleLogout}
              className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground"
            >
              <LogOut className="h-4 w-4" />
              Sair
            </button>
          </div>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          {/* Mobile topbar */}
          <header className="flex items-center justify-between border-b border-border bg-card px-4 py-3 md:hidden">
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Abrir menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent
                side="left"
                className="w-[260px] bg-sidebar p-0 text-sidebar-foreground"
              >
                <SheetTitle className="sr-only">Menu admin</SheetTitle>
                <div className="flex items-center gap-2 px-5 py-5">
                  <span className="flex h-9 w-9 items-center justify-center rounded-full bg-sidebar-primary text-sidebar-primary-foreground">
                    <Leaf className="h-5 w-5" />
                  </span>
                  <p className="font-serif text-base font-semibold">Painel</p>
                </div>
                <NavList onItemClick={() => setOpen(false)} />
                <div className="border-t border-sidebar-border p-3">
                  <button
                    onClick={() => {
                      setOpen(false)
                      handleLogout()
                    }}
                    className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground"
                  >
                    <LogOut className="h-4 w-4" />
                    Sair
                  </button>
                </div>
              </SheetContent>
            </Sheet>
            <p className="font-serif text-base font-semibold">Painel</p>
            <div className="w-9" />
          </header>

          <main className="flex-1 px-4 py-6 md:px-8 md:py-8">{children}</main>
        </div>
      </div>
    </div>
  )
}
