import Link from "next/link"
import { Instagram, MessageCircle, MapPin, Mail, Clock } from "lucide-react"
import { Logo } from "./logo"
import { getSettings } from "@/lib/settings"

export async function SiteFooter() {
  const s = await getSettings()
  const whatsapp = s.whatsapp || "5534988599082"
  const instagram = s.instagram || "uberlandia.plantas"
  const address = s.address || "Uberlândia, MG"
  const email = s.email_contato || "contato@viveirouberlandia.com.br"
  const horario = s.horario || "Seg a Sáb: 8h às 18h"

  return (
    <footer className="bg-sidebar text-sidebar-foreground">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 md:grid-cols-4 md:px-6 md:py-16">
        <div className="md:col-span-2">
          <Logo className="[&_*]:text-sidebar-foreground" />
          <p className="mt-4 max-w-md text-sm leading-relaxed text-sidebar-foreground/70">
            Sua loja de plantas em Uberlândia. Plantas selecionadas com carinho,
            atendimento próximo e dicas para você ter sempre o melhor da natureza em
            casa.
          </p>
          <div className="mt-6 flex gap-3">
            <a
              href={`https://wa.me/${whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex h-10 w-10 items-center justify-center rounded-full bg-sidebar-accent text-sidebar-accent-foreground transition hover:bg-sidebar-primary hover:text-sidebar-primary-foreground"
              aria-label="WhatsApp"
            >
              <MessageCircle className="h-5 w-5" />
            </a>
            <a
              href={`https://instagram.com/${instagram}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex h-10 w-10 items-center justify-center rounded-full bg-sidebar-accent text-sidebar-accent-foreground transition hover:bg-sidebar-primary hover:text-sidebar-primary-foreground"
              aria-label="Instagram"
            >
              <Instagram className="h-5 w-5" />
            </a>
          </div>
        </div>

        <div>
          <h3 className="mb-4 font-serif text-lg font-semibold">Navegação</h3>
          <ul className="space-y-2 text-sm text-sidebar-foreground/70">
            <li>
              <Link href="/" className="hover:text-sidebar-foreground">
                Início
              </Link>
            </li>
            <li>
              <Link href="/estoque" className="hover:text-sidebar-foreground">
                Estoque
              </Link>
            </li>
            <li>
              <Link href="/sobre" className="hover:text-sidebar-foreground">
                Sobre
              </Link>
            </li>
            <li>
              <Link href="/contato" className="hover:text-sidebar-foreground">
                Contato
              </Link>
            </li>
            <li>
              <Link href="/login" className="hover:text-sidebar-foreground">
                Entrar
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="mb-4 font-serif text-lg font-semibold">Contato</h3>
          <ul className="space-y-3 text-sm text-sidebar-foreground/70">
            <li className="flex items-start gap-2">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{address}</span>
            </li>
            <li className="flex items-start gap-2">
              <Mail className="mt-0.5 h-4 w-4 shrink-0" />
              <a href={`mailto:${email}`} className="hover:text-sidebar-foreground">
                {email}
              </a>
            </li>
            <li className="flex items-start gap-2">
              <MessageCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <a
                href={`https://wa.me/${whatsapp}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-sidebar-foreground"
              >
                +55 {whatsapp.slice(2, 4)} {whatsapp.slice(4, 9)}-{whatsapp.slice(9)}
              </a>
            </li>
            <li className="flex items-start gap-2">
              <Clock className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{horario}</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-sidebar-border">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-6 text-xs text-sidebar-foreground/50 md:flex-row md:px-6">
          <p>&copy; {new Date().getFullYear()} Viveiro Uberlândia Plantas. Todos os direitos reservados.</p>
          <p>Feito com cuidado em Uberlândia, MG.</p>
        </div>
      </div>
    </footer>
  )
}
