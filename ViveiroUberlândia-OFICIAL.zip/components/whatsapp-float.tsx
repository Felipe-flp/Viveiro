"use client"

import { MessageCircle } from "lucide-react"

export function WhatsAppFloat({ phone }: { phone: string }) {
  const message = encodeURIComponent(
    "Olá! Gostaria de mais informações sobre as plantas do Viveiro Uberlândia.",
  )
  return (
    <a
      href={`https://wa.me/${phone}?text=${message}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar no WhatsApp"
      className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-transform hover:scale-110"
    >
      <MessageCircle className="h-7 w-7" />
      <span className="sr-only">Falar no WhatsApp</span>
    </a>
  )
}
