import Link from "next/link"
import { Logo } from "./logo"
import { Leaf } from "lucide-react"
import Image from "next/image"

export function AuthShell({
  title,
  subtitle,
  children,
  footer,
}: {
  title: string
  subtitle?: string
  children: React.ReactNode
  footer?: React.ReactNode
}) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="flex flex-col px-4 py-8 md:px-12 md:py-12">
        <div className="mb-12">
          <Logo />
        </div>
        <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center">
          <h1 className="font-serif text-3xl font-semibold md:text-4xl">{title}</h1>
          {subtitle && (
            <p className="mt-2 text-muted-foreground">{subtitle}</p>
          )}
          <div className="mt-8">{children}</div>
          {footer && <div className="mt-6 text-sm">{footer}</div>}
        </div>
        <div className="mt-12 flex justify-center">
          <Link
            href="/"
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            ← Voltar ao site
          </Link>
        </div>
      </div>
      <div className="relative hidden bg-sidebar lg:block">
        <Image
          src="/images/hero-plants.jpg"
          alt=""
          fill
          className="object-cover opacity-90"
          sizes="50vw"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/40 via-sidebar/60 to-sidebar/95" />
        <div className="absolute inset-0 flex flex-col justify-end p-12 text-sidebar-foreground">
          <Leaf className="mb-4 h-10 w-10 text-sidebar-primary" />
          <p className="font-serif text-3xl font-semibold leading-tight">
            “Cuidar de uma planta é cuidar do tempo, da espera e da própria vida.”
          </p>
          <p className="mt-4 text-sm uppercase tracking-widest text-sidebar-foreground/70">
            Viveiro Uberlândia Plantas
          </p>
        </div>
      </div>
    </div>
  )
}
