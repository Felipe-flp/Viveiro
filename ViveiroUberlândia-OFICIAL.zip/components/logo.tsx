import Link from "next/link"
import { Leaf } from "lucide-react"

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link href="/" className={`flex items-center gap-2 ${className}`}>
      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
        <Leaf className="h-5 w-5" aria-hidden />
      </span>
      <span className="flex flex-col leading-tight">
        <span className="font-serif text-base font-semibold tracking-tight">
          Viveiro Uberlândia
        </span>
        <span className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Plantas
        </span>
      </span>
    </Link>
  )
}
