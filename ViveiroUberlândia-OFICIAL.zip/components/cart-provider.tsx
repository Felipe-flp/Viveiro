"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import type { CartItem } from "@/lib/types"

type CartContextValue = {
  items: CartItem[]
  totalItems: number
  totalPrice: number
  addItem: (item: CartItem) => void
  removeItem: (productId: string) => void
  updateQuantity: (productId: string, quantity: number) => void
  clear: () => void
  isOpen: boolean
  setOpen: (open: boolean) => void
}

const CartContext = createContext<CartContextValue | null>(null)

const STORAGE_KEY = "vup_cart"

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [isOpen, setOpen] = useState(false)
  const [hydrated, setHydrated] = useState(false)

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      if (raw) setItems(JSON.parse(raw))
    } catch {}
    setHydrated(true)
  }, [])

  useEffect(() => {
    if (!hydrated) return
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items))
    } catch {}
  }, [items, hydrated])

  function addItem(item: CartItem) {
    setItems((prev) => {
      const existing = prev.find((p) => p.product_id === item.product_id)
      if (existing) {
        const newQty = Math.min(existing.quantity + item.quantity, item.max_quantity)
        return prev.map((p) =>
          p.product_id === item.product_id ? { ...p, quantity: newQty } : p,
        )
      }
      return [...prev, { ...item, quantity: Math.min(item.quantity, item.max_quantity) }]
    })
  }

  function removeItem(productId: string) {
    setItems((prev) => prev.filter((p) => p.product_id !== productId))
  }

  function updateQuantity(productId: string, quantity: number) {
    setItems((prev) =>
      prev
        .map((p) =>
          p.product_id === productId
            ? { ...p, quantity: Math.max(1, Math.min(quantity, p.max_quantity)) }
            : p,
        )
        .filter((p) => p.quantity > 0),
    )
  }

  function clear() {
    setItems([])
  }

  const totalItems = items.reduce((acc, i) => acc + i.quantity, 0)
  const totalPrice = items.reduce((acc, i) => acc + i.quantity * i.price, 0)

  return (
    <CartContext.Provider
      value={{ items, totalItems, totalPrice, addItem, removeItem, updateQuantity, clear, isOpen, setOpen }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error("useCart must be used within CartProvider")
  return ctx
}
