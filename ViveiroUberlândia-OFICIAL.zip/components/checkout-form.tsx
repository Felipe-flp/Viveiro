"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { useCart } from "./cart-provider"
import { createClient } from "@/lib/supabase/client"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Field, FieldLabel, FieldGroup, FieldError, FieldDescription } from "./ui/field"
import { Spinner } from "./ui/spinner"
import { formatBRL } from "@/lib/format"
import { ShoppingBag, MessageCircle, Leaf } from "lucide-react"
import { toast } from "sonner"

export function CheckoutForm({ whatsapp }: { whatsapp: string }) {
  const router = useRouter()
  const { items, totalPrice, clear } = useCart()
  const [name, setName] = useState("")
  const [phone, setPhone] = useState("")
  const [notes, setNotes] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [userEmail, setUserEmail] = useState<string | null>(null)

  useEffect(() => {
    const supabase = createClient()
    supabase.auth.getUser().then(async ({ data: { user } }) => {
      if (!user) return
      setUserEmail(user.email ?? null)
      const { data: profile } = await supabase
        .from("profiles")
        .select("full_name")
        .eq("id", user.id)
        .single()
      if (profile?.full_name) setName(profile.full_name)
    })
  }, [])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)

    if (items.length === 0) {
      setError("Seu carrinho está vazio.")
      return
    }
    if (!name.trim() || !phone.trim()) {
      setError("Preencha nome e telefone.")
      return
    }

    setLoading(true)
    try {
      const supabase = createClient()
      const {
        data: { user },
      } = await supabase.auth.getUser()

      const lines = items.map(
        (i) =>
          `• ${i.quantity}x ${i.name} — ${formatBRL(i.price * i.quantity)}`,
      )
      const whatsappMessage = [
        `*Novo pedido — Viveiro Uberlândia Plantas*`,
        ``,
        `*Cliente:* ${name}`,
        `*Telefone:* ${phone}`,
        userEmail ? `*E-mail:* ${userEmail}` : null,
        notes ? `*Observações:* ${notes}` : null,
        ``,
        `*Itens:*`,
        ...lines,
        ``,
        `*Total: ${formatBRL(totalPrice)}*`,
      ]
        .filter(Boolean)
        .join("\n")

      const { data: order, error: orderError } = await supabase
        .from("orders")
        .insert({
          user_id: user?.id ?? null,
          customer_name: name,
          customer_phone: phone,
          total: totalPrice,
          status: "pending",
          whatsapp_message: whatsappMessage,
        })
        .select()
        .single()

      if (orderError || !order) {
        console.log("[v0] order error", orderError)
        setError("Não foi possível criar o pedido. Tente novamente.")
        setLoading(false)
        return
      }

      const itemsPayload = items.map((i) => ({
        order_id: order.id,
        product_id: i.product_id,
        product_name: i.name,
        unit_price: i.price,
        quantity: i.quantity,
        subtotal: i.price * i.quantity,
      }))

      const { error: itemsError } = await supabase
        .from("order_items")
        .insert(itemsPayload)

      if (itemsError) {
        console.log("[v0] items error", itemsError)
      }

      clear()
      toast.success("Pedido enviado! Te redirecionando para o WhatsApp.")

      const url = `https://wa.me/${whatsapp}?text=${encodeURIComponent(whatsappMessage)}`
      window.open(url, "_blank")

      if (user) {
        router.push(`/minha-conta/pedidos/${order.id}`)
      } else {
        router.push("/")
      }
    } catch (err) {
      console.log("[v0] checkout exception", err)
      setError("Erro inesperado. Tente novamente.")
    } finally {
      setLoading(false)
    }
  }

  if (items.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-border bg-card p-12 text-center">
        <Leaf className="mx-auto mb-3 h-12 w-12 text-muted-foreground" />
        <h2 className="font-serif text-xl">Seu carrinho está vazio</h2>
        <p className="mt-2 text-muted-foreground">
          Adicione plantas para finalizar um pedido.
        </p>
        <Button asChild className="mt-6">
          <Link href="/estoque">Ver estoque</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="grid gap-8 md:grid-cols-[1fr_360px]">
      <form onSubmit={handleSubmit} noValidate className="rounded-2xl border border-border bg-card p-6 md:p-8">
        <h2 className="font-serif text-2xl font-semibold">Seus dados</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Vamos usar essas informações para combinar entrega e pagamento.
        </p>
        <div className="mt-6">
          <FieldGroup>
            <Field>
              <FieldLabel htmlFor="name">Nome completo</FieldLabel>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="phone">WhatsApp / telefone</FieldLabel>
              <Input
                id="phone"
                type="tel"
                placeholder="(34) 9 9999-9999"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
              />
            </Field>
            <Field>
              <FieldLabel htmlFor="notes">Observações (opcional)</FieldLabel>
              <Input
                id="notes"
                placeholder="Endereço, horário preferido, etc."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
              <FieldDescription>
                Você poderá detalhar tudo no WhatsApp depois.
              </FieldDescription>
            </Field>
            {error && <FieldError>{error}</FieldError>}
            <Button type="submit" size="lg" disabled={loading} className="w-full">
              {loading ? (
                <>
                  <Spinner /> Enviando...
                </>
              ) : (
                <>
                  <MessageCircle className="mr-1 h-4 w-4" />
                  Enviar pedido pelo WhatsApp
                </>
              )}
            </Button>
            {!userEmail && (
              <p className="text-center text-xs text-muted-foreground">
                <Link href="/login?redirect=/checkout" className="font-medium text-primary hover:underline">
                  Entre na sua conta
                </Link>{" "}
                para acompanhar este pedido depois.
              </p>
            )}
          </FieldGroup>
        </div>
      </form>

      <aside className="h-fit rounded-2xl border border-border bg-card p-6">
        <h2 className="font-serif text-xl font-semibold">Resumo</h2>
        <ul className="mt-4 divide-y divide-border">
          {items.map((item) => (
            <li key={item.product_id} className="flex gap-3 py-3">
              <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-md bg-muted">
                {item.image_url ? (
                  <Image
                    src={item.image_url || "/placeholder.svg"}
                    alt={item.name}
                    fill
                    className="object-cover"
                    sizes="56px"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center">
                    <ShoppingBag className="h-4 w-4 text-muted-foreground" />
                  </div>
                )}
              </div>
              <div className="flex flex-1 flex-col text-sm">
                <span className="line-clamp-2 font-medium">{item.name}</span>
                <span className="text-muted-foreground">
                  {item.quantity} × {formatBRL(item.price)}
                </span>
              </div>
              <span className="text-sm font-medium">
                {formatBRL(item.price * item.quantity)}
              </span>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex items-center justify-between border-t border-border pt-4">
          <span className="text-sm text-muted-foreground">Total</span>
          <span className="font-serif text-2xl font-semibold text-primary">
            {formatBRL(totalPrice)}
          </span>
        </div>
      </aside>
    </div>
  )
}
