"use client"

import { useState } from "react"
import { Button } from "./ui/button"
import { Minus, Plus, ShoppingBag } from "lucide-react"
import type { Product } from "@/lib/types"
import { useCart } from "./cart-provider"
import { toast } from "sonner"

export function ProductActions({ product }: { product: Product }) {
  const [qty, setQty] = useState(1)
  const { addItem, setOpen } = useCart()
  const outOfStock = product.quantity <= 0

  function handleAdd() {
    if (outOfStock) return
    addItem({
      product_id: product.id,
      name: product.name,
      price: product.price,
      image_url: product.image_url,
      quantity: qty,
      max_quantity: product.quantity,
    })
    toast.success(`${product.name} adicionada ao carrinho`)
    setOpen(true)
  }

  return (
    <div className="flex flex-wrap gap-3">
      <div className="flex items-center gap-1 rounded-md border border-border bg-card">
        <button
          onClick={() => setQty(Math.max(1, qty - 1))}
          disabled={outOfStock || qty <= 1}
          className="p-3 text-foreground/70 hover:bg-secondary disabled:opacity-40"
          aria-label="Diminuir quantidade"
        >
          <Minus className="h-4 w-4" />
        </button>
        <span className="min-w-10 text-center font-medium">{qty}</span>
        <button
          onClick={() => setQty(Math.min(product.quantity, qty + 1))}
          disabled={outOfStock || qty >= product.quantity}
          className="p-3 text-foreground/70 hover:bg-secondary disabled:opacity-40"
          aria-label="Aumentar quantidade"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>
      <Button onClick={handleAdd} disabled={outOfStock} size="lg" className="flex-1">
        <ShoppingBag className="mr-1 h-4 w-4" />
        {outOfStock ? "Indisponível" : "Adicionar ao carrinho"}
      </Button>
    </div>
  )
}
