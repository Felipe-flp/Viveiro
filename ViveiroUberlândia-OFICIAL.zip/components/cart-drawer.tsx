"use client"

import Image from "next/image"
import Link from "next/link"
import { useCart } from "./cart-provider"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "./ui/sheet"
import { Button } from "./ui/button"
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react"
import { formatBRL } from "@/lib/format"

export function CartDrawer() {
  const { items, isOpen, setOpen, totalPrice, updateQuantity, removeItem } = useCart()

  return (
    <Sheet open={isOpen} onOpenChange={setOpen}>
      <SheetContent side="right" className="flex w-full flex-col sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="font-serif text-2xl">Seu carrinho</SheetTitle>
          <SheetDescription>
            {items.length === 0
              ? "Adicione plantas para começar."
              : `${items.length} ${items.length === 1 ? "item" : "itens"} no carrinho`}
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto">
          {items.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-3 p-8 text-center">
              <ShoppingBag className="h-12 w-12 text-muted-foreground" />
              <p className="text-muted-foreground">Seu carrinho está vazio</p>
              <Button asChild onClick={() => setOpen(false)}>
                <Link href="/estoque">Ver estoque</Link>
              </Button>
            </div>
          ) : (
            <ul className="divide-y divide-border">
              {items.map((item) => (
                <li key={item.product_id} className="flex gap-3 py-4">
                  <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-md bg-muted">
                    {item.image_url ? (
                      <Image
                        src={item.image_url || "/placeholder.svg"}
                        alt={item.name}
                        fill
                        className="object-cover"
                        sizes="80px"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-xs text-muted-foreground">
                        sem foto
                      </div>
                    )}
                  </div>
                  <div className="flex flex-1 flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="line-clamp-2 text-sm font-medium leading-tight">
                        {item.name}
                      </h4>
                      <button
                        onClick={() => removeItem(item.product_id)}
                        className="text-muted-foreground hover:text-destructive"
                        aria-label="Remover item"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <p className="mt-1 text-sm font-semibold text-primary">
                      {formatBRL(item.price)}
                    </p>
                    <div className="mt-auto flex items-center justify-between">
                      <div className="flex items-center gap-1 rounded-md border border-border">
                        <button
                          onClick={() =>
                            updateQuantity(item.product_id, item.quantity - 1)
                          }
                          className="p-1.5 text-foreground/70 hover:bg-secondary disabled:opacity-50"
                          disabled={item.quantity <= 1}
                          aria-label="Diminuir quantidade"
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="min-w-8 text-center text-sm">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            updateQuantity(item.product_id, item.quantity + 1)
                          }
                          className="p-1.5 text-foreground/70 hover:bg-secondary disabled:opacity-50"
                          disabled={item.quantity >= item.max_quantity}
                          aria-label="Aumentar quantidade"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        máx. {item.max_quantity}
                      </span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <div className="border-t border-border pt-4">
            <div className="mb-4 flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Subtotal</span>
              <span className="font-serif text-2xl font-semibold">
                {formatBRL(totalPrice)}
              </span>
            </div>
            <Button
              asChild
              size="lg"
              className="w-full"
              onClick={() => setOpen(false)}
            >
              <Link href="/checkout">Finalizar pedido</Link>
            </Button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  )
}
