"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "./ui/button"
import { Input } from "./ui/input"
import { Field, FieldLabel, FieldGroup, FieldError } from "./ui/field"
import { Spinner } from "./ui/spinner"
import { toast } from "sonner"

export function LoginForm({ redirect }: { redirect?: string }) {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      const supabase = createClient()
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      })
      if (signInError) {
        setError("E-mail ou senha incorretos.")
        return
      }
      // check role to decide redirect
      const userId = data.user?.id
      let target = redirect || "/"
      if (userId) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("role, must_change_password")
          .eq("id", userId)
          .single()
        if (profile?.must_change_password) {
          target = "/admin/trocar-senha"
        } else if (
          profile?.role === "admin" ||
          profile?.role === "super_admin"
        ) {
          target = redirect || "/admin"
        }
      }
      toast.success("Login realizado com sucesso!")
      router.push(target)
      router.refresh()
    } catch (err) {
      setError("Erro inesperado. Tente novamente.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate>
      <FieldGroup>
        <Field>
          <FieldLabel htmlFor="email">E-mail</FieldLabel>
          <Input
            id="email"
            type="email"
            placeholder="seu@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="email"
          />
        </Field>
        <Field>
          <FieldLabel htmlFor="password">Senha</FieldLabel>
          <Input
            id="password"
            type="password"
            placeholder="Sua senha"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
          />
        </Field>
        {error && <FieldError>{error}</FieldError>}
        <Button type="submit" size="lg" disabled={loading} className="w-full">
          {loading ? (
            <>
              <Spinner /> Entrando...
            </>
          ) : (
            "Entrar"
          )}
        </Button>
      </FieldGroup>
    </form>
  )
}
