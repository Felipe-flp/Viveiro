"use client"

import Image from "next/image"
import Link from "next/link"
import type { Product } from "@/lib/types"
import { formatBRL } from "@/lib/format"
import { Button } from "./ui/button"
import { ShoppingBag, Leaf } from "lucide-react"
import { useCart } from "./cart-provider"
import { toast } from "sonner"
import { Badge } from "./ui/badge"

export function ProductCard({ product }: { product: Product }) {
  const { addItem, setOpen } = useCart()

  function handleAdd() {
    if (product.quantity <= 0) {
      toast.error("Produto sem estoque no momento.")
      return
    }
    addItem({
      product_id: product.id,
      name: product.name,
      price: product.price,
      image_url: product.image_url,
      quantity: 1,
      max_quantity: product.quantity,
    })
    toast.success(`${product.name} adicionada ao carrinho`)
    setOpen(true)
  }

  const outOfStock = product.quantity <= 0
  const lowStock = product.quantity > 0 && product.quantity <= 3

  return (
    <article className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-all hover:shadow-md">
      <Link
        href={`/produto/${product.id}`}
        className="relative aspect-square overflow-hidden bg-muted"
      >
        {product.image_url ? (
          <Image
            src={product.image_url || "/placeholder.svg"}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            sizes="(max-width: 768px) 50vw, (max-width: 1280px) 33vw, 25vw"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted-foreground">
            <Leaf className="h-12 w-12" />
          </div>
        )}
        {outOfStock && (
          <Badge className="absolute left-3 top-3 bg-destructive text-destructive-foreground">
            Esgotado
          </Badge>
        )}
        {lowStock && !outOfStock && (
          <Badge className="absolute left-3 top-3 bg-accent text-accent-foreground">
            Últimas unidades
          </Badge>
        )}
      </Link>

      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex-1">
          {product.categories?.name && (
            <p className="mb-1 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              {product.categories.name}
            </p>
          )}
          <Link href={`/produto/${product.id}`}>
            <h3 className="line-clamp-2 font-serif text-lg font-medium leading-snug text-foreground hover:text-primary">
              {product.name}
            </h3>
          </Link>
        </div>

        <div className="flex items-end justify-between gap-2">
          <p className="font-serif text-xl font-semibold text-primary">
            {formatBRL(product.price)}
          </p>
          <Button
            size="icon"
            variant="default"
            onClick={handleAdd}
            disabled={outOfStock}
            aria-label="Adicionar ao carrinho"
            className="shrink-0"
          >
            <ShoppingBag className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </article>
  )
}
